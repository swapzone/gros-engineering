(function (angular) {

	'use strict';

	angular.module('app.documents', [
		'ui.router',
		'ngFileUpload',
		'app.api',
		'app.common'
	]);
})(window.angular);
