(function (angular) {

	'use strict';

	angular
		.module('app.documents')
		.controller('DocumentsController', DocumentsController);

	/* @ngInject */
	function DocumentsController($log, $timeout, apiService, spinnerService, user) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('DocumentsController');

			vm.files = [];
			vm.invalidFiles = [];

			vm.uploadSuccess = undefined;
			vm.uploadError = undefined;

			vm.metaData = {
				company: user.companyData.company
			};
		};

		/**
		 * Checks if all required meta data is given.
		 *
		 * @returns {boolean}
		 */
		let isMetaDataComplete = () => {
			return !!(vm.metaData.documentType && vm.metaData.company);
		};

		/**
		 * Upload the files to the back end.
		 */
		let uploadFiles = () => {
			$log.debug('Files: ');
			$log.debug(vm.files);

			if (vm.files && vm.files.length) {
				spinnerService.showSpinner();
				apiService.uploadFiles(user.id, vm.files, vm.metaData)
					.then(() => {
						vm.uploadSuccess = true;

						$timeout(() => {
							vm.files = [];
							vm.metaData = {
								company: user.companyData.company
							};
							vm.uploadSuccess = undefined;
						}, 6000);
					})
					.catch(err => {
						$log.warn(err);
						vm.uploadError = true;

						$timeout(() => {
							vm.uploadError = undefined;
						}, 6000);
					})
					.finally(() => {
						spinnerService.hideSpinner();
					});
			}
		};

		//
		// Controller API
		//
		vm.isMetaDataComplete = isMetaDataComplete;
		vm.uploadFiles = uploadFiles;
	}
})(window.angular);
