(function (angular) {

	'use strict';

	angular
		.module('app.administration')
		.controller('ObjectAdminController', ObjectAdminController);

	/* @ngInject */
	function ObjectAdminController($log, $timeout, apiService, user) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('ObjectAdminController');

			vm.uploadSuccess = undefined;
			vm.uploadError = undefined;
		};

		/**
		 * Upload the files to the back end.
		 */
		vm.uploadFiles = () => {
			$log.debug('File: ');
			$log.debug(vm.file);

			if (vm.file) {
				apiService.uploadApplicationObjectFile(user.id, vm.file)
					.then(() => {
						vm.uploadSuccess = true;

						$timeout(() => {
							vm.file = undefined;
							vm.uploadSuccess = undefined;
						}, 6000);
					})
					.catch(err => {
						$log.warn(err);
						vm.uploadError = true;

						$timeout(() => {
							vm.uploadError = undefined;
						}, 6000);
					});
			}
		};
	}
})(window.angular);
