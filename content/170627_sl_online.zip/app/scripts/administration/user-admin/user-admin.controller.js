(function (angular) {

	'use strict';

	angular
		.module('app.administration')
		.controller('UserAdminController', UserAdminController);

	/* @ngInject */
	function UserAdminController(
		$log,
		$window,
		apiService,
		claimedUserService,
		modalService,
		registrationService,
		user) {
		const vm = this;
		const USER_PAGE_SIZE = 10;

		vm.$onInit = () => {
			$log.debug('UserAdminController');

			apiService.getUsers()
				.then(users => {
					vm.allUsers = users.map(userObject => userObject);
					vm.filteredUsers = users.map(userObject => userObject);

					vm.pages = [];
					const numberOfPages = Math.ceil(vm.filteredUsers.length / USER_PAGE_SIZE);
					for (let i = 1; i < numberOfPages + 1; i++) {
						vm.pages.push(i);
					}

					vm.currentPage = 1;
					vm.users = vm.filteredUsers.slice(0, USER_PAGE_SIZE);
				})
				.catch(error => {
					$log.error('Could not load users.');
					$log.error(error);
				});
		};

		/**
		 * Change page and show contracts accordingly.
		 *
		 * @param page
		 */
		let changePage = page => {
			const startIndex = (page - 1) * USER_PAGE_SIZE;
			vm.currentPage = page;
			vm.users = vm.filteredUsers.slice(startIndex, startIndex + USER_PAGE_SIZE);
		};

		/**
		 * Show a create user form.
		 */
		let createNewUser = () => {
			const modalParams = {
				title: 'Neuen Nutzer anlegen',
				data: {
					formData: {
						value: {},
						required: true
					}
				},
				confirmText: 'Registrieren',
				cancelText: 'Abbrechen',
				validationFn: formData => {
					let result =
						registrationService.validateRegistrationData(formData);
					return result.dataAvailable && result.passwordIsValid && !result.failsPasswordCriteria;
				}
			};

			return modalService.open('new-user', modalParams)
				.then(modalData => {
					return apiService.register(
						modalData.formData.username,
						modalData.formData.password,
						modalData.formData.firstname,
						modalData.formData.lastname,
						modalData.formData.email,
						modalData.formData.contractNumber,
						modalData.formData.company
					);
				})
				.catch(error => {
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Account konnte leider nicht erstellt werden.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
						$log.warn(error);
					}
				});
		};

		/**
		 * Delete a user on the back end and remove it from the list of users in
		 * the front end.
		 *
		 * @param userObject
		 */
		let deleteUser = userObject => {
			let claimedUser = claimedUserService.getClaimedUser();
			if (claimedUser && claimedUser.id === userObject.id) {
				modalService.open('alert', {
					title: 'Aktion fehlgeschlagen',
					data: {
						text: {
							value: 'Sie können einen Nutzer nicht löschen, solange er Ihnen zugeordnet ist.'
						}
					},
					confirmText: 'Ok',
					cancelText: undefined
				});
				return;
			}

			modalService.open('alert', {
				title: 'Sicher?',
				data: {
					text: {
						value: 'Wollen Sie den Nutzer wirklich löschen?'
					}
				},
				confirmText: 'Ok',
				cancelText: 'Abbrechen'
			})
				.then(() => {
					apiService.postAccountAction(userObject.id, 'delete')
						.then(() => {
							// remove user from all relevant arrays
							for (let i = 0; i < vm.allUsers.length; i++) {
								if (vm.allUsers[i].id === userObject.id) {
									vm.allUsers.splice(i, 1);
									break;
								}
							}

							for (let i = 0; i < vm.filteredUsers.length; i++) {
								if (vm.filteredUsers[i].id === userObject.id) {
									vm.filteredUsers.splice(i, 1);
									break;
								}
							}

							for (let i = 0; i < vm.users.length; i++) {
								if (vm.users[i].id === userObject.id) {
									vm.users.splice(i, 1);
									break;
								}
							}
						})
						.catch(() => {
							modalService.open('alert', {
								title: 'Aktion fehlgeschlagen',
								data: {
									text: {
										value: 'Nutzer konnte nicht gelöscht werden.'
									}
								},
								confirmText: 'Ok',
								cancelText: undefined
							});
						});
				});

			// if ($window.confirm('Wollen Sie den Nutzer wirklich löschen?')) {
			// 	apiService.postAccountAction(userObject.id, 'delete')
			// 		.then(() => {
			// 			// remove user from all relevant arrays
			// 			for (let i = 0; i < vm.allUsers.length; i++) {
			// 				if (vm.allUsers[i].id === userObject.id) {
			// 					vm.allUsers.splice(i, 1);
			// 					break;
			// 				}
			// 			}
			//
			// 			for (let i = 0; i < vm.filteredUsers.length; i++) {
			// 				if (vm.filteredUsers[i].id === userObject.id) {
			// 					vm.filteredUsers.splice(i, 1);
			// 					break;
			// 				}
			// 			}
			//
			// 			for (let i = 0; i < vm.users.length; i++) {
			// 				if (vm.users[i].id === userObject.id) {
			// 					vm.users.splice(i, 1);
			// 					break;
			// 				}
			// 			}
			// 		})
			// 		.catch(() => {
			// 			modalService.open('alert', {
			// 				title: 'Aktion fehlgeschlagen',
			// 				data: {
			// 					text: {
			// 						value: 'Nutzer konnte nicht gelöscht werden.'
			// 					}
			// 				},
			// 				confirmText: 'Ok',
			// 				cancelText: undefined
			// 			});
			// 		});
			// }
		};

		/**
		 * Disable a enabled user object.
		 *
		 * @param userObject
		 */
		let disableUser = userObject => {
			apiService.postAccountAction(userObject.id, 'lock')
				.then(() => {
					userObject.locked = true;
				})
				.catch(() => {
					modalService.open('alert', {
						title: 'Aktion fehlgeschlagen',
						data: {
							text: {
								value: 'Nutzer konnte nicht gesperrt werden.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				});
		};

		/**
		 * Show user details in modal.
		 *
		 * @param userObject
		 */
		let showDetails = userObject => {
			let userDetailsData = {
				user: {
					value: userObject,
					required: undefined
				}
			};

			const modalParams = {
				title: 'Nutzerinformationen',
				data: userDetailsData,
				confirmText: 'Schließen'
			};

			modalService.open('user-details', modalParams)
				.catch(error => {
					$log.warn(error);
				});
		};

		/**
		 * Add a user to the administrator's profile.
		 *
		 * @param userObject
		 */
		let claimUser = userObject => {
			apiService.postAccountAction(userObject.id, 'claim')
				.then(profileData => {
					claimedUserService.setClaimedUser(userObject);
					apiService.userInformationRequested = undefined;
					apiService.userInformation = profileData;
				})
				.catch(() => {
					modalService.open('alert', {
						title: 'Aktion fehlgeschlagen',
						data: {
							text: {
								value: 'Nutzer konnte nicht übernommen werden.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				});
		};

		/**
		 * Enable a disabled user object.
		 *
		 * @param userObject
		 */
		let enableUser = userObject => {
			apiService.postAccountAction(userObject.id, 'unlock')
				.then(() => {
					userObject.locked = false;
				})
				.catch(() => {
					modalService.open('alert', {
						title: 'Aktion fehlgeschlagen',
						data: {
							text: {
								value: 'Nutzer konnte nicht entsperrt werden.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				});
		};

		/**
		 * Filter the list of all users.
		 *
		 * @param query
		 */
		let filterUsers = query => {
			if (!query) {
				vm.filteredUsers = vm.allUsers.map(userObject => userObject);
			} else {
				query = query.toLowerCase();

				vm.filteredUsers =	vm.allUsers.filter(userElement => {
					const matchesFirstName = userElement.firstName.toLowerCase().indexOf(query) > -1;
					const matchesLastName = userElement.lastName.toLowerCase().indexOf(query) > -1;
					const matchesCompany = userElement.company && userElement.company.name &&
						userElement.company.name.toLowerCase().indexOf(query) > -1;

					return matchesFirstName || matchesLastName || matchesCompany;
				});
			}

			vm.pages = [];
			const numberOfPages = Math.ceil(vm.filteredUsers.length / USER_PAGE_SIZE);
			for (let i = 1; i < numberOfPages + 1; i++) {
				vm.pages.push(i);
			}

			vm.currentPage = 1;
			vm.users = vm.filteredUsers.slice(0, USER_PAGE_SIZE);
		};

		/**
		 * Initiate password reset for user object.
		 *
		 * @param userObject
		 */
		let resetPassword = userObject => {
			if (userObject.mail) {
				apiService.postAccountAction(undefined, 'reset', {
					email: userObject.mail,
					url: $window.location.origin + $window.location.pathname + '#!/reset/'
				});
			} else {
				modalService.open('alert', {
					title: 'Aktion fehlgeschlagen',
					data: {
						text: {
							value: 'Die Mailadresse des Nutzers ist leider nicht bekannt.'
						}
					},
					confirmText: 'Ok',
					cancelText: undefined
				});
			}
		};

		//
		// Controller API
		//
		vm.changePage = changePage;
		vm.claimUser = claimUser;
		vm.createNewUser = createNewUser;
		vm.deleteUser = deleteUser;
		vm.disableUser = disableUser;
		vm.enableUser = enableUser;
		vm.filterUsers = filterUsers;
		vm.resetPassword = resetPassword;
		vm.showDetails = showDetails;
	}
})(window.angular);
