(function (angular) {

	'use strict';

	angular.module('app.administration', [
		'ui.router',
		'ngFileUpload',
		'app.api',
		'app.common'
	]);
})(window.angular);
