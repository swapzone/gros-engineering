(function (angular) {

	'use strict';

	angular
		.module('app.administration')
		.controller('AdministrationController', AdministrationController);

	/* @ngInject */
	function AdministrationController($log) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('AdministrationController');
		};
	}
})(window.angular);
