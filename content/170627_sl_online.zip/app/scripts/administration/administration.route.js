(function (angular) {

	'use strict';

	angular
		.module('app.administration')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('administration', {
			url: '/administration',
			parent: 'root',
			templateUrl: 'templates/administration/administration.html',
			controller: 'AdministrationController',
			controllerAs: 'vm',
			resolve: {
				/* @ngInject */
				user: ($q, apiService, sessionService, User) => {
					if (sessionService.isAuthenticated()) {
						return apiService.getUserInformation()
							.then(profileData => {
								const user = new User(profileData);
								if (user.isAdministrator()) {
									return user;
								}
								return $q.reject('A normal user is not allowed to access the admin section.');
							});
					}
					return $q.reject('Not authenticated.');
				}
			}
		});

		$stateProvider.state('object-admin', {
			url: '/object-admin',
			parent: 'administration',
			templateUrl: 'templates/administration/object-admin/object-admin.html',
			controller: 'ObjectAdminController',
			controllerAs: 'vm'
		});

		$stateProvider.state('user-admin', {
			url: '/user-admin',
			parent: 'administration',
			templateUrl: 'templates/administration/user-admin/user-admin.html',
			controller: 'UserAdminController',
			controllerAs: 'vm'
		});
	}
})(window.angular);
