(function (angular) {

	'use strict';

	angular.module('app.agb', [
		'ui.router',
		'app.api'
	]);
})(window.angular);
