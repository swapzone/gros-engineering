(function (angular) {

	'use strict';

	angular
		.module('app.contact')
		.controller('ContactController', ContactController);

	/* @ngInject */
	function ContactController($log, $window, apiService, user) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('ContactController');

			vm.errorMessage = null;
			vm.successMessage = null;

			vm.availableSubjects = $window.SL_ONLINE_CONTACT_SUBJECTS;
			if (!vm.availableSubjects || vm.availableSubjects.length === 0) {
				vm.availableSubjects = [
					'Technisches Problem',
					'Mein SüdLeasing Zugang',
					'Sonstiges'
				];
			}

			if (user !== null) {
				vm.name = user.firstName + ' ' + user.lastName;
				vm.phone = user.phone;
				vm.email = user.email;
			}

			vm.contact = 'email';
		};

		/**
		 * Checks if all necessary data is given.
		 *
		 * @returns {boolean}
		 */
		let isFormComplete = () => {
			let contactDataIsComplete =
				(vm.contact === 'phone' && vm.phone) ||
				(vm.contact === 'email' && vm.email);

			return vm.name && vm.subject && vm.message && contactDataIsComplete;
		};

		/**
		 * Sends a contact request to the server.
		 */
		let sendContactRequest = () => {
			vm.errorMessage = null;

			const request = {
				name: vm.name,
				phone: vm.phone,
				email: vm.email,
				contact: vm.contact,
				subject: vm.subject,
				message: vm.message
			};

			$log.debug('Contact request:');
			$log.debug(request);

			apiService.postContactRequest(request)
				.then(() => {
					vm.successMessage = 'Die Nachricht wurde gesendet, vielen Dank.';
				})
				.catch(err => {
					$log.error(err);
					vm.errorMessage = 'Die Nachricht konnte leider aufgrund eines technischen ' +
						'Problems nicht gesendet werden.';
				});
		};

		//
		// Controller API
		//
		vm.isFormComplete = isFormComplete;
		vm.sendContactRequest = sendContactRequest;
	}
})(window.angular);
