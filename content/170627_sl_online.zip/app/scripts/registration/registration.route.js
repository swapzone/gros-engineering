(function (angular) {

	'use strict';

	angular
		.module('app.registration')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('registration', {
			url: '/registration?:confirm',
			parent: 'root',
			templateUrl: 'templates/registration/registration.html',
			controller: 'RegistrationController',
			controllerAs: 'vm'
		});
	}
})(window.angular);
