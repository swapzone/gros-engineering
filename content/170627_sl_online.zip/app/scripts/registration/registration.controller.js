(function (angular) {

	'use strict';

	angular
		.module('app.registration')
		.controller('RegistrationController', RegistrationController);

	/* @ngInject */
	function RegistrationController($log, $state, $stateParams, apiService, modalService, registrationService) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('RegistrationController');

			if ($stateParams.confirm !== undefined) {
				apiService.postAccountConfirmation($stateParams.confirm)
					.then(() => {
						openConfirmationDialog(true);
					})
					.catch(err => {
						openConfirmationDialog(false, err.message);
					});
			}

			vm.formData = {
				value: {}
			};
		};

		/**
		 * Returns true if all required data is given.
		 *
		 * @returns {boolean}
		 */
		let isFormComplete = () => {
			let result =
				registrationService.validateRegistrationData(vm.formData);

			const complete =
				result.dataAvailable && result.passwordIsValid && !result.failsPasswordCriteria;

			return complete && vm.userConfirmation && vm.privacyAgreement;
		};

		/**
		 * Open the account confirm dialog and show success or failure with a given
		 * reason.
		 *
		 * @param success
		 * @param reason
		 */
		let openConfirmationDialog = (success, reason) => {
			if (success) {
				modalService.open('alert', {
					title: 'Aktion erfolgreich.',
					data: {
						text: {
							value: 'Ihr Zugang wurde erfolgreich aktiviert'
						}
					},
					confirmText: 'Ok',
					cancelText: undefined
				}).then(() => {
					$state.go('login');
				});
			} else {
				modalService.open('alert', {
					title: 'Aktion fehlgeschlagen',
					data: {
						text: {
							value: 'Ihr Zugang konnte leider nicht aktiviert werden. ' + reason
						}
					},
					confirmText: 'Ok',
					cancelText: undefined
				}).then(() => {
					$state.go('login');
				});
			}
		};

		/**
		 * Register a new user.
		 */
		let register = () => {
			if (isFormComplete()) {
				apiService.register(
					vm.formData.value.username,
					vm.formData.value.password,
					vm.formData.value.firstname,
					vm.formData.value.lastname,
					vm.formData.value.email,
					vm.formData.value.contractNumber,
					vm.formData.value.company
				)
					.then(() => {
						modalService.open('alert', {
							title: 'Registrierung erfolgreich',
							data: {
								text: {
									value: 'Sie werden innerhalb der nächsten Minuten eine ' +
									'Bestätigungsmail mit einem Bestätigungslink erhalten, mit ' +
									'dem Sie Ihre Registrierung bestätigen können. Der Zugang ' +
									'wird erst nach der Bestätigung vollständig aktiviert werden.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						}).then(() => {
							$state.go('login');
						});
					})
					.catch(err => {
						$log.warn(err);
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: err.message || 'Account konnte leider nicht erstellt werden.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					});
			}
		};

		//
		// Controller API
		//
		vm.isFormComplete = isFormComplete;
		vm.register = register;
	}
})(window.angular);
