(function (angular) {

	'use strict';

	angular
		.module('app.calculator')
		.controller('CalculatorController', CalculatorController);

	/* @ngInject */
	function CalculatorController($log, $scope, apiService, spinnerService, user) {
		const vm = this;

		let watchers = [];

		vm.$onInit = () => {
			$log.debug('CalculatorController');

			vm.files = [];

			apiService.getLeasingCategories()
				.then(categories => {
					vm.categories = categories;
				})
				.catch(err => {
					$log.error('Categories could not be retrieved: ');
					$log.error(err);
				});

			vm.durationOptions = [];

			vm.formData = {
				category: undefined,
				subCategory: undefined,
				objectCondition: 'new',
				dateBuilt: undefined,
				objectDetails: '',
				investment: undefined,
				listPrice: undefined,
				contractType: 'PARTIAL_AMORTISATION',
				duration: 24,
				downPayment: {
					value: 0,
					type: 'amount'
				},
				recoveryValue: {
					value: 0,
					type: 'amount'
				}
			};

			let categoryWatcher = $scope.$watch('vm.formData.category', () => {
				if (vm.formData.category) {
					vm.subCategories =
						vm.categories.filter(category => category.label === vm.formData.category.label)[0].subCategories;
				}
			});

			let subCategoryWatcher = $scope.$watch('vm.formData.subCategory', () => {
				if (vm.formData.subCategory) {
					vm.durationOptions = vm.formData.subCategory.durations;
					vm.formData.duration = vm.durationOptions[0];
				}
			});

			let formWatcher = $scope.$watch('vm.formData', () => {
				// $log.debug('Form data changed!');
				if (vm.monthlyRate) {
					vm.monthlyRate = undefined;
				}
			}, true);

			watchers = [categoryWatcher, subCategoryWatcher, formWatcher];
		};

		$scope.$on('$destroy', () => {
			watchers.forEach(watcher => {
				watcher();
			});
		});

		/**
		 * Start the calculation process by calling the appropriate API.
		 */
		let calculate = () => {
			apiService.postCalculationRequest(user, vm.formData)
				.then(results => {
					$log.debug('Calculation results: ');
					$log.debug(results);

					vm.calculationError = false;
					vm.monthlyRate = results.monthlyRate;
				})
				.catch(error => {
					$log.error('Could not calculate contract data: ');
					$log.error(error.message);
					vm.errorMessage = error.message;
					vm.calculationError = true;
				});
		};

		/**
		 * Returns the icon designator for the given value type.
		 *
		 * @param value
		 * @returns {string}
		 */
		let getIconForValueType = value => {
			return value.type === 'amount' ? 'eur' : 'percent';
		};

		/**
		 * Checks if the necessary input was made.
		 *
		 * @returns {boolean}
		 */
		let isFormComplete = () => {
			if (!vm.formData.duration || vm.formData.duration < 24) {
				vm.inputErrorMessage = 'Die Finanzierungsdauer muss mindestens 24 Monate betragen.';
			} else {
				vm.inputErrorMessage = undefined;
			}

			let allDataAvailable =
				vm.formData.category !== undefined &&
				vm.formData.subCategory !== undefined &&
				vm.formData.investment !== undefined &&
				vm.formData.duration;

			if (vm.formData.objectCondition !== 'new') {
				allDataAvailable = allDataAvailable &&
					vm.formData.dateBuilt !== undefined &&
					vm.formData.listPrice !== undefined;
			}

			return !vm.inputErrorMessage && allDataAvailable;
		};

		/**
		 * Send a request to the back end telling sales that the customer wants to
		 * get a quote.
		 */
		let requestOffer = () => {
			spinnerService.showSpinner();
			apiService.postQuoteRequest(user, vm.formData, vm.files)
				.then(() => {
					vm.errorMessage = undefined;
					vm.successMessage = 'Das Angebot wurde erfolgreich ' +
						'angefordert und wird in den kommenden Tagen bei Ihnen ' +
						'eintreffen.';
				})
				.catch(err => {
					$log.error(err);
					vm.successMessage = undefined;
					vm.errorMessage = 'Das Angebot konnte leider aufgrund eines ' +
						'technischen Problems nicht angefordert werden.';
				})
				.finally(() => {
					spinnerService.hideSpinner();
				});
		};

		/**
		 * Toggle the value type for the given input.
		 *
		 * @param input
		 */
		let toggleValueType = input => {
			input.type = input.type === 'amount' ? 'percent' : 'amount';
		};

		//
		// Controller API
		//
		vm.calculate = calculate;
		vm.getIconForValueType = getIconForValueType;
		vm.isFormComplete = isFormComplete;
		vm.requestOffer = requestOffer;
		vm.toggleValueType = toggleValueType;
	}
})(window.angular);
