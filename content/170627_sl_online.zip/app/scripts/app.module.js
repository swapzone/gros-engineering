(function (angular) {

	'use strict';

	angular
		.module('app', [
			'ui.router',
			'app.api',
			'app.templates',
			'app.common',
			'app.agb',
			'app.contact',
			'app.contracts',
			'app.calculator',
			'app.documents',
			'app.account',
			'app.administration',
			'app.login',
			'app.registration',
			'app.reset'
		])
		.constant('ROLES', {
			user: 'User',
			admin: {
				tech: 'ObjectAdmin',
				user: 'UserAdmin',
				impersonated: 'WorkFor'
			}
		})
		.run(run);

	/* @ngInject */
	function run($cookies, $http, $log, $rootScope, $state, $window, apiService, sessionService, trackingService, User) {
		const activeLanguage = $cookies.get('sl_lang') || $window.SL_ONLINE_LANGUAGE || 'de_DE';
		$log.debug('Active language: ' + activeLanguage);

		if (sessionService.isAuthenticated()) {
			$http.defaults.headers.common = {
				'jwt-token': sessionService.getAuthenticationToken(),
				'x-language': activeLanguage,
				'Content-Type': 'application/json'
			};
		}

		if ($window.SL_ONLINE_TRACK_USER) {
			trackingService.activateUserTracking();
		} else {
			$log.info('User tracking is inactive.');
		}

		$rootScope.$on('$stateChangeStart',
			function (event, toState) {
				// prevent user from going to the login page if the user is already authenticated
				if (sessionService.isAuthenticated() && toState.name === 'login') {
					event.preventDefault();

					apiService.getUserInformation()
						.then(userInformation => {
							if (new User(userInformation).isAdministrator()) {
								$state.go('administration');
							} else {
								$state.go('contracts');
							}
						});
				}

				// always go to the login page if the user is not authenticated
				// an exception is the result and support screen, which can be visited at any time
				const validStates = ['agb', 'login', 'contact', 'registration', 'passwordReset', 'reset'];

				if (!sessionService.isAuthenticated() && validStates.indexOf(toState.name) === -1) {
					event.preventDefault();
					$state.go('login');
				}
			});
	}
})(window.angular);

