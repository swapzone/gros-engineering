(function (angular) {

	'use strict';

	angular
		.module('app.reset')
		.controller('ResetController', ResetController);

	/* @ngInject */
	function ResetController($log, $state, $stateParams, apiService, modalService) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('ResetController');

			if (!$stateParams.hash) {
				throw Error('No hash given for reset state.');
			}

			$log.debug('Hash value: ' + $stateParams.hash);

			let resetPasswordData = {
				password: {
					value: undefined,
					required: true
				},
				passwordConfirm: {
					value: undefined,
					required: true
				}
			};

			const modalParams = {
				title: 'Passwort zurücksetzen',
				data: resetPasswordData,
				confirmText: 'Zurücksetzen',
				cancelText: 'Abbrechen',
				validationFn: formData => {
					return formData.password.value && formData.password.value === formData.passwordConfirm.value;
				}
			};

			modalService.open('new-password', modalParams)
				.then(() => {
					return apiService.resetPassword(resetPasswordData.password.value, $stateParams.hash);
				})
				.then(() => {
					$log.debug('Password successfully reset.');
					$state.go('login');
				})
				.catch(error => {
					$log.warn(error);
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: error.message || 'Das Passwort konnte leider nicht zurückgesetzt werden.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
					$state.go('login');
				});
		};
	}
})(window.angular);
