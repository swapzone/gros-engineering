(function (angular) {

	'use strict';

	angular.module('app.reset', [
		'ui.router',
		'app.common',
		'app.api'
	]);
})(window.angular);
