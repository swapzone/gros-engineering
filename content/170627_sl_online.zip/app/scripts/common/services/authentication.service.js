(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.service('authenticationService', authenticationService);

	/* @ngInject */
	function authenticationService($http, $q, $rootScope, apiService, claimedUserService, sessionService) {
		const service = this;

		/**
		 * Login user on the server to retrieve access token.
		 *
		 * @param username
		 * @param password
		 * @param remember
		 * @param adminLogin
		 * @returns {*}
		 */
		let login = (username, password, remember, adminLogin) => {
			return $q((resolve, reject) => {
				apiService.authenticate(username, password, adminLogin)
					.then(authenticationResult => {
						sessionService.storeAuthenticationToken(authenticationResult.token, remember);

						apiService.userInformationRequested = undefined;
						apiService.userInformation = undefined;

						$http.defaults.headers.common = {
							'jwt-token': authenticationResult.token
						};

						$rootScope.$emit('authenticationEvent');
						resolve(authenticationResult);
					})
					.catch(reject);
			});
		};

		/**
		 * Remove authentication token from storage and request header.
		 *
		 * @returns {*}
		 */
		let logout = () => {
			sessionService.removeAuthenticationToken();
			claimedUserService.unsetClaimedUser();
			apiService.userInformationRequested = undefined;
			apiService.userInformation = undefined;
			$rootScope.$emit('authenticationEvent');
			delete $http.defaults.headers.common['jwt-token'];
		};

		//
		// Service API
		//
		service.login = login;
		service.logout = logout;
	}
})(window.angular);
