(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.service('sessionService', sessionService);

	/* @ngInject */
	function sessionService($localStorage, $sessionStorage) {
		const service = this;

		/**
		 * Stores token to the local storage.
		 *
		 * @param {string} token
		 * @param {boolean} rememberToken
		 */
		let storeAuthenticationToken = (token, rememberToken) => {
			$sessionStorage['sl-user-token'] = token;

			if (rememberToken) {
				$localStorage['sl-user-token'] = token;
			}
		};

		/**
		 * Returns the authentication token.
		 */
		let getAuthenticationToken = () => {
			let token = $sessionStorage['sl-user-token'];

			if (!token) {
				token = $localStorage['sl-user-token'];
			}

			return token;
		};

		/**
		 * Removes the authentication token from the local storage.
		 */
		let removeAuthenticationToken = () => {
			delete $sessionStorage['sl-user-token'];
			delete $localStorage['sl-user-token'];
		};

		/**
		 * Return true if the user is already authenticated.
		 *
		 * @returns {boolean}
		 */
		let isAuthenticated = () => {
			return !!service.getAuthenticationToken();
		};

		//
		// Service API
		//
		service.storeAuthenticationToken = storeAuthenticationToken;
		service.getAuthenticationToken = getAuthenticationToken;
		service.isAuthenticated = isAuthenticated;
		service.removeAuthenticationToken = removeAuthenticationToken;
	}
})(window.angular);
