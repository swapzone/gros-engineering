(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.factory('User', userFactory);

	/* @ngInject */
	function userFactory(Roles) {

		/**
		 * Constructor function for User object.
		 *
		 * @param profile
		 * @constructor
		 */
		function User(profile) {
			if (profile) {
				this.id = profile.userId;
				this.userName = profile.userName;
				this.firstName = profile.firstName;
				this.lastName = profile.lastName;
				this.email = profile.email;
				this.phone = profile.phone;
				this.companyData = profile.companyData;
				this.roles = Roles.build(profile.roles);
				this.calculationAllowed = profile.calculationAllowed;
				this.contractDownloadAllowed = profile.contractDownloadAllowed;
				this.agbAccepted = profile.agbAccepted;
				this.profileInReview = !!profile.profileInReview;
			} else {
				// create dummy user
				this.id = -1;
				this.userName = '';
				this.firstName = '';
				this.lastName = '';
				this.email = '';
				this.phone = '';
				this.companyData = {};
				this.roles = Roles.build(['User']);
				this.calculationAllowed = false;
				this.contractDownloadAllowed = false;
				this.agbAccepted = 0;
				this.profileInReview = false;
			}
		}

		/**
		 * Returns true, if the user has an admin role.
		 *
		 * @returns {boolean}
		 */
		User.prototype.isAdministrator = function () {
			return this.roles.isAdministrator();
		};

		/**
		 * Returns true, if the user has the user role.
		 *
		 * @returns {boolean}
		 */
		User.prototype.isUser = function () {
			return this.roles.isUser();
		};

		/**
		 * Returns true, if the user has the user role.
		 *
		 * @returns {boolean}
		 */
		User.prototype.hasAcceptedBusinessTerms = function () {
			return this.agbAccepted;
		};

		/**
		 * Private function to check validity of profile object.
		 * Must be enhanced to check if all required properties are available.
		 *
		 * @param profile
		 * @returns {boolean}
		 */
		function checkProfile(profile) {
			return profile.hasOwnProperty('roles');
		}

		/**
		 * Static method, assigned to class.
		 * Instance ('this') is not available in a static context.
		 *
		 * @param profile
		 * @returns {User}
		 */
		User.build = function (profile) {
			if (!checkProfile(profile)) {
				return null;
			}
			return new User(profile);
		};

		// return constructor function
		return User;
	}
})(window.angular);
