(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.factory('authInterceptor', authInterceptor)
		.factory('requestInterceptor', requestInterceptor);

	/* @ngInject */
	function authInterceptor($injector, $q, sessionService) {
		return {
			responseError: response => {
				const $state = $injector.get('$state');
				if (response.status === 401 && $state.current.name !== 'login') {
					sessionService.removeAuthenticationToken();
					$state.go('login', { previous: $state.current.name });
				}

				if (response.status === 403 && sessionService.isAuthenticated() && $state.current.name !== 'login') {
					sessionService.removeAuthenticationToken();
					$state.go('login', { previous: $state.current.name });
				}

				return $q.reject(response);
			}
		};
	}

	/* @ngInject */
	function requestInterceptor($q, spinnerService) {
		return {
			request: config => {
				if (config.showWaitingSpinner && config.showWaitingSpinner === true) {
					spinnerService.showSpinner();
				}
				return config;
			},
			response: response => {
				let config = response.config;
				if (config.showWaitingSpinner && config.showWaitingSpinner === true) {
					spinnerService.hideSpinner();
				}
				return response;
			},
			requestError: rejectReason => {
				spinnerService.hideSpinner();
				return $q.reject(rejectReason);
			},
			responseError: response => {
				spinnerService.hideSpinner();
				return $q.reject(response);
			}
		};
	}
})(window.angular);
