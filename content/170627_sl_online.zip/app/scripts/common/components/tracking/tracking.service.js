(function (angular, moment) {

	'use strict';

	angular
		.module('app.common')
		.service('trackingService', trackingService);

	/* @ngInject */
	function trackingService($log, $rootScope, $state, apiService) {
		const service = this;

		// set this variable to true to activate user tracking
		service.isTrackingActive = false;

		let registerStateSuccessHandler = () => {
			$rootScope.$on('$stateChangeSuccess',	(event, toState) => {
				service.trackEvent('STATE_TRANSITION', {
					target: undefined,
					position: undefined,
					state: toState.name,
					error: undefined
				});
			});
		};

		let registerClickHandler = () => {
			window.addEventListener('click', event => {
				if (event.target.dataset.hasOwnProperty('trackEvent')) {
					// do not track clicks that target an element that is already tracked
					return;
				}

				let tagNamesToTrack = ['input', 'button', 'a', 'select', 'textarea'];

				if (tagNamesToTrack.indexOf(event.target.tagName.toLowerCase()) > -1) {
					service.trackEvent('CLICK', {
						target: {
							element: event.target.tagName.toLowerCase(),
							label: event.target.name || event.target.className.split(' ')[0],
							value: event.target.value
						},
						position: {
							x: event.clientX,
							y: event.clientY
						},
						state: $state.current.name,
						error: undefined
					});
				}
			});
		};

		/**
		 * Register all required event listeners that should track something.
		 */
		let registerEventListeners = () => {
			registerStateSuccessHandler();
			registerClickHandler();
		};

		/**
		 * Activate user tracking.
		 */
		let activateUserTracking = () => {
			service.isTrackingActive = true;
			registerEventListeners();
		};

		/**
		 * Compose tracking message and send to server.
		 *
		 * @param eventName
		 * @param trackingData
		 */
		let trackEvent = (eventName, trackingData) => {
			if (!service.isTrackingActive) {
				return;
			}

			trackingData.user = $rootScope.user ? $rootScope.user.id : 'anonymous';
			trackingData.action = eventName.toUpperCase();
			trackingData.time = moment().format('YYYY-MM-DDTHH:mm:ssZ');

			// $log.debug('Tracking data:');
			// $log.debug(trackingData);

			let message = trackingData.time + ',' + trackingData.action + ',' + trackingData.state;

			if (trackingData.target) {
				message += ',' + trackingData.target.element + '|' +
					trackingData.target.label + '|' + trackingData.target.value;
			} else {
				message += ',undefined';
			}

			if (trackingData.position) {
				message += ',' + trackingData.position.x + '|' + trackingData.position.y;
			} else {
				message += ',undefined';
			}

			if (trackingData.error) {
				message += ',' + String(trackingData.error);
			} else {
				message += ',undefined';
			}

			message += ',' + trackingData.user;

			apiService.postLogMessage(message).catch($log.warn);
		};

		//
		// Service API
		//
		service.activateUserTracking = activateUserTracking;
		service.trackEvent = trackEvent;
	}
})(window.angular, window.moment);
