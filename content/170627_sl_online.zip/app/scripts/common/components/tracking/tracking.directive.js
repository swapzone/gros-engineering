(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.directive('trackEvent', trackEvent);

	/* @ngInject */
	function trackEvent($log, $state, trackingService) {
		return {
			restrict: 'A',
			link: ($scope, $element, $attrs) => {
				let eventType = $attrs.trackEvent || 'click';
				let trackingData = {};

				angular.element($element[0]).bind(eventType, $event => {
					trackingData.target = {
						element: $element[0].tagName.toLowerCase(),
						label: inferEventName($element[0]),
						value: $attrs.trackEventValue
					};
					trackingData.position = {
						x: $event.clientX,
						y: $event.clientY
					};
					trackingData.state = $state.current.name;
					trackingData.error = undefined;

					trackingService.trackEvent(eventType, trackingData);
				});
			}
		};

		function isCommand(element) {
			return ['a:', 'button:', 'button:button', 'button:submit', 'input:button', 'input:submit'].indexOf(
					element.tagName.toLowerCase() + ':' + (element.type || '')) >= 0;
		}

		function inferEventName(element) {
			if (isCommand(element)) {
				return element.innerText || element.value;
			}
			return element.id || element.name || element.tagName;
		}
	}
})(window.angular);
