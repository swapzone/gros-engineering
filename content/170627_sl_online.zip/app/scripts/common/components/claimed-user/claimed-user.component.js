(function (angular) {
	'use strict';

	angular
		.module('app.common')
		.component('claimedUser', {
			controller: ClaimedUserController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/claimed-user/claimed-user.html'
		});

	/* @ngInject */
	function ClaimedUserController($scope, $state, apiService, modalService, claimedUserService) {
		const vm = this;

		vm.$onInit = () => {
			if (claimedUserService.hasClaimedUser()) {
				vm.user = claimedUserService.getClaimedUser();
			}

			let watcher = $scope.$on('userClaimed', () => {
				vm.user = claimedUserService.getClaimedUser();
			});

			$scope.$on('$destroy', () => {
				watcher();
			});
		};

		/**
		 * Remove the claimed user from the administrator UI.
		 */
		let unclaimUser = () => {
			apiService.postAccountAction(vm.user.id, 'unclaim')
				.then(() => {
					claimedUserService.unsetClaimedUser();
					vm.user = undefined;
					apiService.userInformationRequested = undefined;
					apiService.userInformation = undefined;
					$state.go('user-admin');
				})
				.catch(() => {
					modalService.open('alert', {
						title: 'Aktion fehlgeschlagen',
						data: {
							text: {
								value: 'Der Nutzer konnte nicht freigegeben werden.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				});
		};

		//
		// Component API
		//
		vm.unclaimUser = unclaimUser;
	}
})(window.angular);
