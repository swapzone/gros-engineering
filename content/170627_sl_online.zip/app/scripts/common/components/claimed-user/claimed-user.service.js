(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.service('claimedUserService', claimedUserService);

	/* @ngInject */
	function claimedUserService($rootScope, $sessionStorage) {
		const service = this;

		let getClaimedUser = () => {
			return $sessionStorage['sl-claimed-user'];
		};

		let hasClaimedUser = () => {
			return !!$sessionStorage['sl-claimed-user'];
		};

		let setClaimedUser = user => {
			$sessionStorage['sl-claimed-user'] = user;
			$rootScope.$broadcast('userClaimed');
		};

		let unsetClaimedUser = () => {
			service.claimedUser = undefined;
			delete $sessionStorage['sl-claimed-user'];
		};

		//
		// Service API
		//
		service.getClaimedUser = getClaimedUser;
		service.hasClaimedUser = hasClaimedUser;
		service.setClaimedUser = setClaimedUser;
		service.unsetClaimedUser = unsetClaimedUser;
	}
})(window.angular);
