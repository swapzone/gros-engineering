(function (angular, jasmine) {

	'use strict';

	describe('Module: app.common', function () {
		describe('Component: translate', function () {
			let $componentController;
			let $translate;
			let controller;

			beforeEach(() => {
				window.Translations = {
					de_DE: { test: 'Test' },
					en_US: { test: 'Test' }
				};
			});

			beforeEach(module('app.common'));
			beforeEach(angular.mock.inject(function (_$componentController_, _$translate_) {
				$componentController = _$componentController_;
				$translate = _$translate_;
				controller = $componentController('languagePicker');
			}));

			it('should be created successfully', function () {
				expect(controller).toBeDefined();
			});

			it('should have a setLanguage method', function () {
				expect(controller.setLanguage).toEqual(jasmine.any(Function));
			});

			it('should call $translate.use', function () {
				const language = 'de_DE';
				spyOn($translate, 'use');
				controller.setLanguage(language);
				expect($translate.use).toHaveBeenCalledWith(language);
			});
		});
	});
})(window.angular, window.jasmine);
