(function (angular) {
	'use strict';

	angular
		.module('app.common')
		.component('paging', {
			controller: PagingController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/paging/paging.html',
			bindings: {
				pages: '<',
				currentPage: '<',
				onPageChanged: '&',
			}
		});

	/* @ngInject */
	function PagingController($log, $scope) {
		const vm = this;

		let initComponent = () => {
			// $log.debug('Page length: ' + vm.pages.length);
			if (vm.pages.length > 10) {
				if (vm.currentPage < 5) {
					vm.visiblePages = vm.pages.slice(0, 5);
					vm.beforeControl = false;
				} else {
					vm.visiblePages = vm.pages.slice(vm.currentPage - 3, 5);
					vm.beforeControl = true;
				}
				vm.afterControl = vm.visiblePages[vm.visiblePages.length - 1] < vm.pages[vm.pages.length - 1];
			} else {
				vm.visiblePages = vm.pages;
				vm.beforeControl = false;
				vm.afterControl = false;
			}
		};

		vm.$onInit = () => {
			if (!vm.pages || !vm.pages.length) {
				$scope.$watchCollection('vm.pages', value => {
					if (value && value.length) {
						initComponent();
					}
				});
				return;
			}
			initComponent();
		};

		/**
		 * Can next page be selected.
		 */
		let isNextPageControlActive = () => {
			return vm.currentPage < vm.pages.length;
		};

		/**
		 * Is given page the active one.
		 *
		 * @param page
		 */
		let isPageControlActive = (page) => {
			return vm.currentPage !== page;
		};

		/**
		 * Can a previous page be selected.
		 */
		let isPreviousPageControlActive = () => {
			return vm.currentPage > 1;
		};

		/**
		 * Show the next bunch of pages in the pagination control.
		 */
		let loadNextPages = () => {
			$log.debug('Show next pages section');

			const lastShownPage = vm.visiblePages[vm.visiblePages.length - 1];
			let endIndex = lastShownPage + 4;
			if (endIndex > vm.pages.length - 1) {
				endIndex = vm.pages.length;
			}

			vm.visiblePages = vm.pages.slice(endIndex - 5, endIndex);

			vm.beforeControl = true;
			vm.afterControl = vm.visiblePages[vm.visiblePages.length - 1] < vm.pages[vm.pages.length - 1];
		};

		/**
		 * Show the previous bunch of pages in the pagination control.
		 */
		let loadPreviousPages = () => {
			$log.debug('Show previous pages section');

			const firstShownPage = vm.visiblePages[0];
			let startIndex = firstShownPage - 6;
			if (startIndex < 0) {
				startIndex = 0;
			}

			vm.visiblePages = vm.pages.slice(startIndex, startIndex + 5);

			vm.beforeControl = vm.visiblePages[0] > 1;
			vm.afterControl = true;

		};

		/**
		 * Select the next page.
		 */
		let selectNextPage = () => {
			if (vm.currentPage < vm.pages.length) {
				vm.onPageChanged({ page: vm.currentPage + 1 });
			}
		};

		/**
		 * Select the previous page.
		 */
		let selectPreviousPage = () => {
			if (vm.currentPage > 1) {
				vm.onPageChanged({ page: vm.currentPage - 1 });
			}
		};

		/**
		 * Select the given page.
		 *
		 * @param page
		 */
		let selectPage = (page) => {
			if (page !== vm.currentPage) {
				vm.onPageChanged({ page: page });
			}
		};

		//
		// Component API
		//
		vm.isNextPageControlActive = isNextPageControlActive;
		vm.isPageControlActive = isPageControlActive;
		vm.isPreviousPageControlActive = isPreviousPageControlActive;
		vm.loadNextPages = loadNextPages;
		vm.loadPreviousPages = loadPreviousPages;
		vm.selectNextPage = selectNextPage;
		vm.selectPreviousPage = selectPreviousPage;
		vm.selectPage = selectPage;
	}
})(window.angular);
