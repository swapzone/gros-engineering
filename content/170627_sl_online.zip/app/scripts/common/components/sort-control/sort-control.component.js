(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('sortControl', {
			controller: SortControlController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/sort-control/sort-control.html',
			bindings: {
				sortOrder: '<',
				sortAscending: '&',
				sortDescending: '&',
				doNotSort: '&'
			}
		});

	/* @ngInject */
	function SortControlController() {
		const vm = this;

		vm.sort = () => {
			switch (vm.sortOrder) {
				case 1:
					vm.sortDescending();
					break;
				case 2:
					vm.doNotSort();
					break;
				default:
					vm.sortAscending();
					break;
			}
		};
	}
})(window.angular);

