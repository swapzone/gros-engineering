(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('waitingSpinner', {
			controller: SpinnerController,
			controllerAs: 'waitingSpinner',
			templateUrl: 'templates/common/components/spinner/spinner.html'
		});

	/* @ngInject */
	function SpinnerController(spinnerService, $timeout) {
		const vm = this;

		vm.$onInit = () => {
			vm.isShowing = false;

			spinnerService.registerSpinnerHandler(isShowingSpinner => {
				$timeout(() => {
					vm.isShowing = isShowingSpinner;
				}, 0);
			});
		};
	}
})(window.angular);

