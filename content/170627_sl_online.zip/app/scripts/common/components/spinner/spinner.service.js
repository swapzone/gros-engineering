(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.service('spinnerService', spinnerService);

	/* @ngInject */
	function spinnerService() {
		const service = this;

		let spinnerInvokeCounter = 0;

		function showSpinner() {
			// $log.debug('Show spinner.');
			spinnerInvokeCounter++;
			if (service.spinnerHandler) {
				service.spinnerHandler(true);
			}
		}

		function hideSpinner() {
			if (spinnerInvokeCounter > 0) {
				spinnerInvokeCounter--;
			}
			// $log.debug('Hide spinner. Counter: ' + spinnerInvokeCounter);
			if (service.spinnerHandler) {
				if (spinnerInvokeCounter <= 0) {
					spinnerInvokeCounter = 0;
					service.spinnerHandler(false);
				}
			}
		}

		/**
		 * Handler is provided by waiting-spinner component.
		 *
		 * @param {any} handler
		 */
		function registerSpinnerHandler(handler) {
			service.spinnerHandler = handler;
		}

		//
		// Service API
		//
		service.showSpinner = showSpinner;
		service.hideSpinner = hideSpinner;
		service.registerSpinnerHandler = registerSpinnerHandler;
	}
})(window.angular);
