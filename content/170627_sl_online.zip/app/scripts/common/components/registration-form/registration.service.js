(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.service('registrationService', registrationService);

	/* @ngInject */
	function registrationService($log) {
		const service = this;

		function validateRegistrationData(formData) {
			if (!formData || !formData.value) {
				return {
					dataAvailable: false,
					passwordIsValid: false,
					failsPasswordCriteria: true
				};
			}

			let result = {
				dataAvailable: true,
				passwordIsValid: true,
				failsPasswordCriteria: false
			};

			result.dataAvailable = !!(
				formData.value.username && formData.value.email && formData.value.firstname &&
				formData.value.lastname && formData.value.company && formData.value.contractNumber &&
				formData.value.password && formData.value.passwordConfirm);

			result.passwordIsValid =
				!formData.value.password || !formData.value.passwordConfirm ||
				formData.value.password === formData.value.passwordConfirm;

			result.failsPasswordCriteria = formData.value.password && !isPasswordValid(formData.value.password);

			return result;
		}

		function isPasswordValid(password) {
			let matchesComplianceRules = 0;

			if (password.length < 8) {
				$log.debug('too_short');
				return false;
			}

			if (password.search(/\d/) === -1) {
				$log.debug('no_num');
			} else {
				matchesComplianceRules++;
			}

			if (password.search(/[a-z]/) === -1) {
				$log.debug('no_letter');
			} else {
				matchesComplianceRules++;
			}

			if (password.search(/[A-Z]/) === -1) {
				$log.debug('no_capital_letter');
			} else {
				matchesComplianceRules++;
			}

			if (password.search(/[!@#$%^&*()_+]/) === -1) {
				$log.debug('no_special_char');
			} else {
				matchesComplianceRules++;
			}

			return matchesComplianceRules > 2;
		}

		//
		// Service API
		//
		service.validateRegistrationData = validateRegistrationData;
	}
})(window.angular);
