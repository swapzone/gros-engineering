(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('modal', {
			controller: ModalController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/modal/modal.html'
		});

	/* @ngInject */
	function ModalController($log, $rootScope, modalService) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('ModalController');

			$rootScope.$on('modals.open', () => {
				vm.title = modalService.params().title || 'Meldung';
				vm.message = modalService.params().message;
				vm.modalData = modalService.params().data;
				vm.confirmText = modalService.params().confirmText || 'Ok';
				vm.cancelText = modalService.params().cancelText;
				vm.validationFn = modalService.params().validationFn;

				if (modalService.params().templateUrl) {
					vm.templateUrl = modalService.params().templateUrl;
				}

				vm.show = true;
			});

			$rootScope.$on('modals.close', () => {
				vm.title = undefined;
				vm.message = undefined;
				vm.confirmText = undefined;
				vm.cancelText = undefined;
				vm.templateUrl = undefined;
				vm.validationFn = undefined;

				vm.show = false;
			});
		};

		let cancel = () => {
			modalService.reject('Modal was closed.');
		};

		let close = () => {
			modalService.reject('Modal was closed.');
		};

		/**
		 * Confirm the modal dialog and return associated data.
		 */
		let confirm = () => {
			let formIsValid = true;
			let transformedModalData = {};
			for (let property in vm.modalData) {
				if (vm.modalData.hasOwnProperty(property)) {
					transformedModalData[property] = vm.modalData[property].value;
					if (vm.modalData[property].required && vm.modalData[property].value === undefined) {
						formIsValid = false;
					}
				}
			}

			if (formIsValid) {
				vm.errorMessage = undefined;
				modalService.resolve(transformedModalData);
			} else {
				vm.errorMessage = 'Alle Pflichtfelder müssen korrekt ausgefüllt sein.';
			}
		};

		/**
		 * Checks the validity of the form with the given validation function.
		 *
		 * @returns {*}
		 */
		let formIsValid = () => {
			return !vm.validationFn || vm.validationFn(vm.modalData);
		};

		/**
		 * Only show the mandatory field note on some specific modals.
		 *
		 * @returns {boolean}
		 */
		let showMandatoryField = () => {
			let templatesWithMandatoryFields = [
				'templates/common/components/modal/views/balance-confirmation.html',
				'templates/common/components/modal/views/bank-account.html',
				'templates/common/components/modal/views/cancel-contract.html',
				'templates/common/components/modal/views/change-password.html',
				'templates/common/components/modal/views/claim-report.html',
				'templates/common/components/modal/views/extend-contract.html',
				'templates/common/components/modal/views/new-password.html',
				'templates/common/components/modal/views/new-user.html',
				'templates/common/components/modal/views/password-reset.html'
			];
			return templatesWithMandatoryFields.indexOf(vm.templateUrl) > -1;
		};

		//
		// Controller API
		//
		vm.cancel = cancel;
		vm.close = close;
		vm.confirm = confirm;
		vm.formIsValid = formIsValid;
		vm.showMandatoryField = showMandatoryField;
	}
})(window.angular);

