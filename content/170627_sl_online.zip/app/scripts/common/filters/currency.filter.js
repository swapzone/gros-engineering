(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.filter('currency', currencyFilter);

	/* @ngInject */
	function currencyFilter($log) {
		return (input, currency) => {
			if (!input) {
				return '';
			}

			if (currency === 'USD') {
				return typeof input === 'string' ?
					'$' + input : '$' + input.toFixed(2);
			}

			if (typeof input === 'string') {
				$log.info('Monthly rate is given as string.');
				return input + ' Euro';
			}
			$log.info('Monthly rate is given as number.');
			let fraction = (input % 1).toFixed(2).substr(2);
			return Math.floor(input).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + fraction + ' Euro';
		};
	}
})(window.angular);
