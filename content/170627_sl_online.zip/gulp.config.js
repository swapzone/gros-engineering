module.exports = function () {

	const jsFiles = [
		'app/scripts/app.module.js',
		'app/scripts/**/*.module.js',
		'app/scripts/**/*.js',
		'!app/scripts/**/*.spec.js'
	];

	// 'node_modules/angular-sanitize/angular-sanitize.min.js',

	const jsLibraryFiles = [
		'node_modules/jquery/dist/jquery.min.js',
		'node_modules/moment/min/moment.min.js',
		'node_modules/moment/locale/de.js',
		'node_modules/angular/angular.min.js',
		'node_modules/angular-sanitize/angular-sanitize.min.js',
		'node_modules/angular-ui-router/release/angular-ui-router.min.js',
		'node_modules/angular-moment-picker/dist/angular-moment-picker.js',
		'node_modules/angular-animate/angular-animate.min.js',
		'node_modules/angular-translate/dist/angular-translate.min.js',
		'node_modules/angular-cookies/angular-cookies.min.js',
		'node_modules/ngstorage/ngStorage.min.js',
		'node_modules/ng-file-upload/dist/ng-file-upload.min.js'
	];

	return {
		// directory structure
		app: 'app/',
		build: 'build/',
		scripts: 'app/scripts/',
		styles: 'app/styles/',

		// script files
		js: jsFiles,

		// external dependencies
		jsLibs: jsLibraryFiles,

		// test files
		jsTest: [].concat(
			jsLibraryFiles,
			'node_modules/angular-mocks/angular-mocks.js',
			jsFiles,
			'app/scripts/**/*.spec.js'
		),

		cssLibs: [
			'app/styles/legacy/*.css',
			'node_modules/angular-moment-picker/dist/angular-moment-picker.css'
		],

		fonts: [
			'app/styles/fonts/**/*'
		]
	};
};
