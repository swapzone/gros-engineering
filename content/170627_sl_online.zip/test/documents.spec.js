(function () {

	'use strict';

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;
	const fs = require('fs');

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function(done) {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);

		driver.get(APP_URL);
		driver.executeScript(function () {
			return sessionStorage.setItem('ngStorage-sl-user-token', '\"FakeToken\"');
		});
		driver.navigate().refresh().then(() => {
			done();
		});
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Documents', function() {
		this.timeout(30000);

		beforeEach(function() {
			driver.get(APP_URL + '/#!/documents');
		});

		it('should open the documents section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/documents').notify(done);
		});

		it('should have all necessary input in the file property form', done => {
			let counter = 0;
			driver.get(APP_URL + '/#!/documents');

			let companyNameElementTag = driver.findElement(By.name('company')).getTagName();
			let documentTypeElementTag = driver.findElement(By.name('document-type')).getTagName();

			expect(companyNameElementTag).to.eventually.equal('input').notify(setToDone);
			expect(documentTypeElementTag).to.eventually.equal('select').notify(setToDone);

			function setToDone(error) {
				if (error) {
					return done(error);
				}
				counter++;
				if (counter === 2) {
					done();
				}
			}
		});

		it('should show the pre-filled file property form', done => {
			driver.get(APP_URL + '/#!/documents');

			let companyName = driver.findElement(By.name('company')).getAttribute('value');
			expect(companyName).to.eventually.equal('Coole Firma').notify(done);
		});
	});
})();
