(function () {

	'use strict';

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function(done) {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);

		driver.get(APP_URL);
		driver.executeScript(function () {
			return sessionStorage.setItem('ngStorage-sl-user-token', '\"FakeToken\"');
		});
		driver.navigate().refresh().then(() => {
			done();
		});
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Administration', function() {
		this.timeout(30000);

		it('should open the administration section', done => {
			driver.get(APP_URL + '/#!/administration');
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/administration').notify(done);
		});

		it('should have the administration menu open', done => {
			driver.get(APP_URL + '/#!/administration');

			// /* Example how to take a screenshot */
			// let screenShot = driver.findElement({
			// 	css: '.level-1 .main-link.first > a > span'
			// }).takeScreenshot();
			//
			// screenShot.then(data => {
			// 	let name = 'screenshot.png';
			// 	let screenShotPath = 'C:\\Users\\extsth01\\Desktop\\';
			// 	require('fs').writeFileSync(screenShotPath + name, data, 'base64');
			// });

			let menuItemText = driver.findElement(By.css('.level-1 .main-link.first > a > span')).getText();
			expect(menuItemText).to.eventually.equal('NUTZERVERWALTUNG').notify(done);
		});

		it('should open a modal for adding a new user', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');

			driver.findElement(By.css('.sl-user-admin .sl-button')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('NEUEN NUTZER ANLEGEN').notify(done);
		});

		it('should show the existing users', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');

			let resultItems = driver.findElements(By.css('.sl-user-admin-users-list li'));
			resultItems.then(items => {
				expect(items.length).to.equal(8);
				done();
			});
		});

		it('should open the user details when clicking on the user icon', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');
			driver.findElement(By.css('.fa-info-circle')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('NUTZERINFORMATIONEN').notify(done);
		});

		it('should ask for confirmation before deleting the user', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');
			driver.findElement(By.css('.fa-trash-o')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('SICHER?').notify(done);
		});

		it('should offer an input to search for user', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');
			let searchBoxPlaceholder =
				driver.findElement(By.css('.sl-user-admin-search-box > input')).getAttribute('placeholder');

			expect(searchBoxPlaceholder).to.eventually.equal('z.B. Vor- oder Nachname oder Firma').notify(done);
		});

		it('should offer a password reset element for each user', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');
			let elementText = driver.findElement(By.css('.password-reset')).getText();
			expect(elementText).to.eventually.equal('Passwort zurücksetzen').notify(done);
		});

		it('should offer an interaction element to lock an user account', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');
			let elementText = driver.findElement(By.css('.lock-user')).getText();
			expect(elementText).to.eventually.equal('Account sperren').notify(done);
		});

		it('should offer an interaction element to unlock a locked user account', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');
			let elementText = driver.findElement(By.css('.unlock-user')).getText();
			expect(elementText).to.eventually.equal('Account aktivieren').notify(done);
		});

		it('should offer an interaction element to impersonate a user', done => {
			driver.get(APP_URL + '/#!/administration/user-admin');
			 driver.findElement(By.css('.fa-user')).click();
			let elementText = driver.findElement(By.css('.sl-claimed-user-notification > .text')).getText();
			expect(elementText).to.eventually.equal('Ihr Profil ist derzeit mit dem folgenden ' +
				'Nutzer verknüpft:').notify(done);
		});
	});
})();
