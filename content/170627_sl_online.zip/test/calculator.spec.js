(function () {

	'use strict';

	const {Builder,By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function(done) {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);

		driver.get(APP_URL);
		driver.executeScript(function () {
			return sessionStorage.setItem('ngStorage-sl-user-token', '\"FakeToken\"');
		});
		driver.navigate().refresh().then(() => {
			done();
		});
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Calculator', function() {
		this.timeout(30000);

		beforeEach(function() {
			driver.get(APP_URL + '/#!/calculator');
		});

		it('should open the calculator section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/calculator').notify(done);
		});

		it('should initially deactivate the submit button', done => {
			let disabled =
				driver.findElement(By.css('.sl-calculator .sl-calculator-form .sl-button')).getAttribute('disabled');
			expect(disabled).to.eventually.equal('true').notify(done);
		});

		it('should ask for date built when \'Gebraucht\' is selected', done => {
			driver.findElement(By.id('object-condition-used')).click();
			let placeholder = driver.findElement(By.id('date-built')).getAttribute('placeholder');
			expect(placeholder).to.eventually.equal('MM/JJJJ').notify(done);
		});

		it('should populate the duration dropdown when a category and sub-category was selected', done => {
			driver.findElement(By.id('category')).sendKeys('Baumaschinen');
			driver.findElement(By.id('sub-category')).sendKeys('Bagger');
			let selected = driver.findElement(By.css('select#duration>option:first-of-type')).getAttribute('selected');
			expect(selected).to.eventually.equal('true').notify(done);
		});

		it('should change from Euro to percent when clicking on it', done => {
			driver.findElement(By.css('input[name=down-payment]+span')).click();
			let className = driver.findElement(By.css('input[name=down-payment]+span>i')).getAttribute('class');
			expect(className).to.eventually.equal('fa fa-percent').notify(done);
		});

		it('should change the wording if \'Mietkauf\' is selected', done => {
			driver.findElement(By.id('contract-type-purchase')).click();
			let elementText = driver.findElement(By.css('label[for=recovery-value]')).getText();
			expect(elementText).to.eventually.equal('Gewünschte Schlusszahlung').notify(done);
		});

		it('should activate the submit button when all data is given', done => {
			driver.findElement(By.name('category')).sendKeys('Baumaschinen');
			driver.findElement(By.name('sub-category')).sendKeys('Bagger');
			driver.findElement(By.name('investment')).sendKeys(1000);

			let disabled =
				driver.findElement(By.css('.sl-calculator .sl-calculator-form .sl-button')).getAttribute('disabled');
			expect(disabled).to.eventually.equal(null).notify(done);
		});

		it('should show the calculated rate', done => {
			driver.findElement(By.name('category')).sendKeys('Baumaschinen');
			driver.findElement(By.name('sub-category')).sendKeys('Bagger');
			driver.findElement(By.name('investment')).sendKeys(1000);
			driver.findElement(By.css('.sl-calculator .sl-calculator-form .sl-button')).click();
			setTimeout(() => {
				let calculatedRate = driver.findElement(By.css('.sl-calculator-result > span:nth-of-type(2)')).getText();
				expect(calculatedRate).to.eventually.equal('1.230,40 Euro *').notify(done);
			}, 3000);
		});

		it('should show a document upload button after the calculation', done => {
			driver.findElement(By.name('category')).sendKeys('Baumaschinen');
			driver.findElement(By.name('sub-category')).sendKeys('Bagger');
			driver.findElement(By.name('investment')).sendKeys(1000);
			driver.findElement(By.css('.sl-calculator .sl-calculator-form .sl-button')).click();
			setTimeout(() => {
				let documentUploadArea = driver.findElement(By.css('.sl-calculator-result > .sl-calculator-document-upload')).getTagName();
				expect(documentUploadArea).to.eventually.equal('div').notify(done);
			}, 3000);
		});

		it('should confirm that an offer was requested', done => {
			driver.findElement(By.name('category')).sendKeys('Baumaschinen');
			driver.findElement(By.name('sub-category')).sendKeys('Bagger');
			driver.findElement(By.name('investment')).sendKeys(1000);
			driver.findElement(By.css('.sl-calculator .sl-calculator-form .sl-button')).click();
			setTimeout(() => {
				driver.findElement(By.id('btn-request-offer')).click();
				let calculatedRate = driver.findElement(By.css('.sl-calculator-result > .sl-label-success')).getText();
				expect(calculatedRate).to.eventually.equal('Das Angebot wurde erfolgreich angefordert und wird in den kommenden Tagen bei Ihnen eintreffen.').notify(done);
			}, 3000);
		});
	});
})();
