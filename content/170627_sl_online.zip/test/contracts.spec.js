(function () {

	'use strict';

	let contracts = require('../mock/contracts.json');

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function(done) {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);

		driver.get(APP_URL);
		driver.executeScript(function () {
			return sessionStorage.setItem('ngStorage-sl-user-token', '\"FakeToken\"');
		});
		driver.navigate().refresh().then(() => {
			done();
		});
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Contracts', function() {
		this.timeout(30000);

		beforeEach(function() {
			driver.get(APP_URL + '/#!/contracts');
		});

		it('should open the contracts section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/contracts').notify(done);
		});

		it('should show all contracts of a customer in a table', done => {
			driver.findElements(By.className('sl-contracts-item'))
				.then(elements => {
					const PAGE_SIZE = 10;
					const numberOfContracts = contracts.length;

					let elementsInTable = numberOfContracts > PAGE_SIZE ? PAGE_SIZE : numberOfContracts;
					expect(elements.length).to.equal(elementsInTable);
					done();
				});
		});

		it('should show all required contract attributes in the table', done => {
			let counter = 0;

			driver.findElements(By.className('sl-contracts-header-title'))
				.then(elements => {
					expect(elements.length).to.equal(6);
					expect(elements[0].getText()).to.eventually.equal('Vertragsnummer').notify(setToDone);
					expect(elements[1].getText()).to.eventually.equal('Vertragsart').notify(setToDone);
					expect(elements[2].getText()).to.eventually.equal('Vertragsbeginn').notify(setToDone);
					expect(elements[3].getText()).to.eventually.equal('Vertragsende').notify(setToDone);
					expect(elements[4].getText()).to.eventually.equal('Status').notify(setToDone);
					expect(elements[5].getText()).to.eventually.equal('Objekt').notify(setToDone);
				});

			function setToDone(error) {
				if (error) {
					return done(error);
				}
				counter++;
				if (counter === 6) {
					done();
				}
			}
		});

		it('should offer the user a search box to search through all contracts', done => {
			let inputPlaceholder = driver.findElement(By.css('.sl-contracts-search-box > input')).getAttribute('placeholder');
			expect(inputPlaceholder).to.eventually.equal('Durchsuchen Sie Ihre Verträge').notify(done);
		});

		it('should show the filters when clicking on it', done => {
			driver.findElement(By.css('.sl-element-toggle.filter')).click();
			let placeholder = driver.findElement(By.css('.date-picker')).getAttribute('placeholder');
			expect(placeholder).to.eventually.equal('DD.MM.YYYY').notify(done);
		});

		// it('should show the sort field selection when clicking on it', done => {
		// 	driver.findElement(By.css('.sl-element-toggle.sort')).click();
		// 	let ngModel = driver.findElement(By.id('sort-field')).getAttribute('data-ng-model');
		// 	expect(ngModel).to.eventually.equal('vm.sortField').notify(done);
		// });

		it('should open a the menu when clicking on the contract action button', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			let elementText = driver.findElement(By.css('.sl-contracts-action-menu > a:last-of-type')).getText();
			expect(elementText).to.eventually.equal('Bankverbindung ändern').notify(done);
		});

		it('should open \'Saldenbestaetigung\' for a contract', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(2)')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('SALDENBESTÄTIGUNG ANFORDERN').notify(done);
		});

		it('should open \'Vertragsverlaengerung\' for a contract', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(4)')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('VERTRAGSVERLÄNGERUNG').notify(done);
		});

		it('should offer a date picker for \'Vertragsverlaengerung\'', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(4)')).click();
			let datePickerMode = driver.findElement(By.css('.moment-picker-contents > div')).getAttribute('data-max-view');
			expect(datePickerMode).to.eventually.equal('month').notify(done);
		});

		it('should offer a comment field for \'Vertragsverlaengerung\'', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(4)')).click();
			let commentFieldTagName = driver.findElement(By.name('annotation')).getTagName();
			expect(commentFieldTagName).to.eventually.equal('textarea').notify(done);
		});

		it('should open \'Vertrag vorzeitig abloesen\' for a contract', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(3)')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('VERTRAG ABLÖSEN').notify(done);
		});

		it('should offer a date picker for \'Vertrag vorzeitig abloesen\'', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(3)')).click();
			let datePickerMode = driver.findElement(By.css('.moment-picker-contents > div')).getAttribute('data-max-view');
			expect(datePickerMode).to.eventually.equal('year').notify(done);
		});

		it('should offer a comment field for \'Vertrag vorzeitig abloesen\'', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(3)')).click();
			let commentFieldTagName = driver.findElement(By.name('annotation')).getTagName();
			expect(commentFieldTagName).to.eventually.equal('textarea').notify(done);
		});

		it('should show a remark on leasing contracts', done => {
			driver.findElements(By.css('.sl-contracts-actions')).then(elements => {
				elements[1].findElement(By.css('a:first-of-type')).click();
				driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(3)')).click();
				let remarkText = driver.findElement(By.id('sl-cancel-contract-annotation')).getText();
				expect(remarkText).to.eventually.equal('Anmerkung: Keine vorzeitige Kaufmöglichkeit ' +
					'des Leasingobjektes vor Ablauf von 40 % der im Vertrag bestimmten betriebsgewöhnlichen ' +
					'Nutzungsdauer.').notify(done);
			});
		});

		it('should open \'Schadenmeldung\' for a contract', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(5)')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('VERSICHERUNGSSCHADEN MELDEN').notify(done);
		});

		it('should force the user to give all data in the \'Schadenmeldung\' form', done => {
			let counter = 0;

			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(5)')).click();

			let insuranceRequired = driver.findElement(By.name('insurance')).getAttribute('required');
			let streetRequired = driver.findElement(By.name('street')).getAttribute('required');
			let cityRequired = driver.findElement(By.name('city')).getAttribute('required');
			let zipRequired = driver.findElement(By.name('zip')).getAttribute('required');
			let errorLabelText = driver.findElement(By.css('.sl-label-error')).getText();

			expect(insuranceRequired).to.eventually.equal('true').notify(setToDone);
			expect(streetRequired).to.eventually.equal('true').notify(setToDone);
			expect(cityRequired).to.eventually.equal('true').notify(setToDone);
			expect(zipRequired).to.eventually.equal('true').notify(setToDone);
			expect(errorLabelText).to.eventually.equal('Es muss entweder die Versicherungsnummer ' +
				'oder die Schadennummer angegeben werden.').notify(setToDone);

			function setToDone(error) {
				if (error) {
					return done(error);
				}
				counter++;
				if (counter === 5) {
					done();
				}
			}
		});

		it('should hide \'Vertrag verlaengern\' for a contract that is not due in the next six months', done => {
			driver.findElements(By.css('.sl-contracts-actions > a:first-of-type'))
				.then(elements => {
					elements[3].click();
					let menuItemText = driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(4)')).getText();
					expect(menuItemText).to.eventually.equal('Versicherungsschaden melden').notify(done);
				});
		});

		it('should load new contracts when going to another page', done => {
			setTimeout(() => {
				driver.findElement(By.css('.pagination > a:nth-of-type(3)')).click();
				let spinnerAttribute = driver.findElement(By.css('.waiting-spinner-modal')).getAttribute('class');
				expect(spinnerAttribute).to.eventually.equal('waiting-spinner-modal active').notify(done);
			}, 3000);
		});

		it('should offer a button to change the bank account per contract', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			let buttonLabel = driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(6)')).getText();
			expect(buttonLabel).to.eventually.equal('Bankverbindung ändern').notify(done);
		});
	});
})();
