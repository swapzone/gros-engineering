(function () {

	'use strict';

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function(done) {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);

		driver.get(APP_URL);
		driver.executeScript(function () {
			return sessionStorage.setItem('ngStorage-sl-user-token', '\"FakeToken\"');
		});
		driver.navigate().refresh().then(() => {
			done();
		});
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Account', function() {
		this.timeout(30000);

		beforeEach(function() {
			driver.get(APP_URL + '/#!/account');
		});

		it('should open the account section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/account').notify(done);
		});

		// it('should have the bank account number anonymized', done => {
		// 	let text = driver.findElement(By.name('bank-account')).getAttribute('value');
		// 	expect(text).to.eventually.equal('XX XXXX XXXX XXXX XXXX 9538').notify(done);
		// });

		it('should open the password change modal', done => {
			driver.findElement(By.id('change-password')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('PASSWORT ÄNDERN').notify(done);
		});

		it('should ask for the old password', done => {
			driver.findElement(By.id('change-password')).click();
			let passwordType = driver.findElement(By.name('old-password')).getAttribute('type');
			expect(passwordType).to.eventually.equal('password').notify(done);
		});

		it('should deactivate the submit button when required data is missing', done => {
			driver.findElement(By.name('email')).clear();

			let disabled = driver.findElement({
				css: '.sl-account-form .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal('true').notify(done);
		});

		it('should activate the submit button when all data is given', done => {
			driver.findElement(By.name('company')).sendKeys('test');
			driver.findElement(By.name('legal-form')).sendKeys('test');
			driver.findElement(By.name('address')).sendKeys('test');
			driver.findElement(By.name('zip-code')).sendKeys('123456');
			driver.findElement(By.name('city')).sendKeys('test');
			driver.findElement(By.name('email')).sendKeys('test@test.de');

			setTimeout(() => {
				let disabled = driver.findElement({
					css: '.sl-account-form .sl-button'
				}).getAttribute('disabled');

				expect(disabled).to.eventually.equal(null).notify(done);
			}, 500);
		});

		it('should offer a button for the user to logout', done => {
			let logoutButtonClass = driver.findElement(By.id('logout')).getAttribute('class');
			expect(logoutButtonClass).to.eventually.equal('home').notify(done);
		});
	});
})();
