(function () {

	'use strict';

	const {ActionSequence, Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function() {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Registration', function () {
		this.timeout(30000);

		beforeEach(function () {
			driver.get(APP_URL + '/#!/registration');
		});

		it('should open the registration section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/registration').notify(done);
		});

		it('should have a registration button', done => {
			let text = driver.findElement({
				css: '.sl-registration .sl-button'
			}).getText();

			expect(text).to.eventually.equal('ACCOUNT ERSTELLEN').notify(done);
		});

		it('should hide the tooltip initially', done => {
			let toolTipHiddenClass = driver.findElement(By.className('sl-tooltip')).getAttribute('class');
			expect(toolTipHiddenClass).to.eventually.equal('sl-tooltip ng-hide').notify(done);
		});

		it('should show the tooltip upon hover', done => {
			let infoIcon = driver.findElement(By.className('fa-info'));
			let action = new ActionSequence(driver);
			action.mouseMove(infoIcon).perform();
			let toolTipClass = driver.findElement(By.className('sl-tooltip')).getAttribute('class');
			expect(toolTipClass).to.eventually.equal('sl-tooltip').notify(done);
		});

		it('should deactivate the registration button as long as required data is missing', done => {
			let disabled = driver.findElement({
				css: '.sl-registration .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal('true').notify(done);
		});

		it('should activate the registration button when all data is given and the checkboxes are selected', done => {
			driver.findElement(By.name('username')).sendKeys('123456789');
			driver.findElement(By.name('contract-number')).sendKeys('1234');
			driver.findElement(By.name('company')).sendKeys('test');
			driver.findElement(By.name('firstname')).sendKeys('ralf');
			driver.findElement(By.name('lastname')).sendKeys('maier');
			driver.findElement(By.name('email')).sendKeys('test@test.de');
			driver.findElement(By.name('password')).sendKeys('123456ab$');
			driver.findElement(By.name('password-confirm')).sendKeys('123456ab$');
			driver.findElement(By.name('user-confirm')).click();
			driver.findElement(By.name('privacy-agreement')).click();

			driver.findElements(By.css('.sl-label-error'))
				.then(elements => {
					expect(elements.length).to.equal(0);
				});

			let disabled = driver.findElement({
				css: '.sl-registration .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal(null).notify(done);
		});

		it('should offer an optional phone input', done => {
			let required = driver.findElement(By.name('phone')).getAttribute('required');
			expect(required).to.eventually.equal(null).notify(done);
		});

		it('should inform the user when the two given passwords do not match', done => {
			driver.findElement(By.name('password')).sendKeys('ab$123456');
			driver.findElement(By.name('password-confirm')).sendKeys('ab$1234567');

			setTimeout(() => {
				let errorMessage = driver.findElement(By.css('.sl-label-error')).getText();
				expect(errorMessage).to.eventually.equal('Die zwei Passwörter stimmen nicht überein.').notify(done);
			}, 1000);
		});

		it('should inform the user when the password does not comply with the password policy', done => {
			driver.findElement(By.name('password')).sendKeys('1234');
			driver.findElement(By.name('password-confirm')).sendKeys('1234');

			setTimeout(() => {
				// we need the timeout here because of the model debounce feature
				let errorMessage = driver.findElement(By.css('.sl-label-error')).getText();
				expect(errorMessage).to.eventually.equal('Das Passwort entspricht nicht den Passwortrichtlinien. ' +
					'Es muss mindestens 8 Zeichen lang sein und aus Zahlen, Buchstaben und mindestens einem Sonderzeichen bestehen.').notify(done);
			}, 1000);
		});

		it('should force the user to agree upon the data privacy terms', done => {
			driver.findElement(By.name('username')).sendKeys('123456789');
			driver.findElement(By.name('contract-number')).sendKeys('1234');
			driver.findElement(By.name('company')).sendKeys('test');
			driver.findElement(By.name('firstname')).sendKeys('ralf');
			driver.findElement(By.name('lastname')).sendKeys('maier');
			driver.findElement(By.name('email')).sendKeys('test@test.de');
			driver.findElement(By.name('password')).sendKeys('123456ab$');
			driver.findElement(By.name('password-confirm')).sendKeys('123456ab$');
			driver.findElement(By.name('user-confirm')).click();

			let disabled = driver.findElement({
				css: '.sl-registration .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal('true').notify(done);
		});

		it('should force the user to confirm his right to register on behalf of the company', done => {
			driver.findElement(By.name('username')).sendKeys('123456789');
			driver.findElement(By.name('contract-number')).sendKeys('1234');
			driver.findElement(By.name('company')).sendKeys('test');
			driver.findElement(By.name('firstname')).sendKeys('ralf');
			driver.findElement(By.name('lastname')).sendKeys('maier');
			driver.findElement(By.name('email')).sendKeys('test@test.de');
			driver.findElement(By.name('password')).sendKeys('123456ab$');
			driver.findElement(By.name('password-confirm')).sendKeys('123456ab$');
			driver.findElement(By.name('privacy-agreement')).click();

			let disabled = driver.findElement({
				css: '.sl-registration .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal('true').notify(done);
		});

		it('should link to the login section', done => {
			driver.findElement({
				linkText: 'Login'
			}).click();

			setTimeout(() => {
				// we need the timeout here because PhantomJS takes some time to start the transition
				expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/login').notify(done);
			}, 2000);
		});
	});
})();
