(function () {

	'use strict';

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function(done) {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);

		driver.get(APP_URL);
		driver.executeScript(function () {
			return sessionStorage.setItem('ngStorage-sl-user-token', '\"FakeToken\"');
		});
		driver.navigate().refresh().then(() => {
			done();
		});
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Contact', function () {
		this.timeout(30000);

		beforeEach(function () {
			driver.get(APP_URL + '/#!/contact');
		});

		it('should open the contact section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/contact').notify(done);
		});

		it('should have the user data pre-filled', done => {
			let userName = driver.findElement(By.name('name')).getAttribute('value');
			let userEmail = driver.findElement(By.name('email')).getAttribute('value');

			expect(userName).to.eventually.equal('Max Mustermann').notify(error => {
				if (error) {
					return done(error);
				}
				expect(userEmail).to.eventually.equal('max@suedleasing.com').notify(done);
			});
		});

		it('should have a submit button', done => {
			let text = driver.findElement({
				css: '.sl-contact .sl-contact-form .sl-button'
			}).getText();

			expect(text).to.eventually.equal('ABSCHICKEN').notify(done);
		});

		it('should deactivate the submit button as long as required data is missing', done => {
			let disabled = driver.findElement({
				css: '.sl-contact .sl-contact-form .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal('true').notify(done);
		});

		it('should activate the submit button when all data is given and valid', done => {
			driver.findElement(By.name('subject')).sendKeys('Technisches Problem');
			driver.findElement(By.name('name')).sendKeys('1234');
			driver.findElement(By.name('email')).sendKeys('test@test.de');
			driver.findElement(By.name('message')).sendKeys('test');

			let disabled = driver.findElement({
				css: '.sl-contact .sl-contact-form .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal(null).notify(done);
		});

		it('should deactivate the submit button when phone is selected but not given', done => {
			driver.findElement(By.name('subject')).sendKeys('Technisches Problem');
			driver.findElement(By.name('name')).sendKeys('1234');
			driver.findElement(By.name('message')).sendKeys('test');
			driver.findElement(By.name('phone')).clear();
			driver.findElement(By.id('contact-phone')).click();

			let disabled = driver.findElement({
				css: '.sl-contact .sl-contact-form .sl-button'
			}).getAttribute('disabled');

			expect(disabled).to.eventually.equal('true').notify(done);
		});
	});
})();
