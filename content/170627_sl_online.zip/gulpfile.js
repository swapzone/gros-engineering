'use strict';

// include gulp
const gulp = require('gulp');

// include karma test runner
const KarmaServer = require('karma').Server;

// include core modules
const path 	  = require('path'),
	    fs	    = require('fs'),
			through = require('through2'),
	    spawn	  = require('child_process').spawn;

const merge = require('merge-stream');

const del = require('del');

// include gulp plugin loader
const $ = require('gulp-load-plugins')({ lazy: true });

/****************************************************************************************************/
/* SETTING UP DEVELOPMENT ENVIRONMENT                                                               */
/****************************************************************************************************/
const gulpConfig = require('./gulp.config')();
let production = false;

// the title and icon that will be used for notifications
const notifyInfo = {
	title: 'Gulp',
	icon: path.join(__dirname, 'gulp.png')
};

// error notification settings for plumber
const plumberErrorHandler = {
	errorHandler: $.notify.onError({
		title: notifyInfo.title,
		icon: notifyInfo.icon,
		message: "Error: <%= error.message %>"
	})
};

/****************************************************************************************************/
/* DEVELOPMENT TASKS                                                                                */
/****************************************************************************************************/

// run linter to ensure code quality
gulp.task('run:cqa', function () {
	return gulp
		.src([
			gulpConfig.scripts + '**/*.js'
		])
		.pipe($.eslint())
		.pipe($.eslint.format())
		.pipe($.eslint.failAfterError());
});

// copy font files and compile styles
gulp.task('build:styles', function() {

	const vendorStyles = gulp.src(gulpConfig.cssLibs)
		.pipe($.concat('vendor.css'))
		.pipe(gulp.dest(gulpConfig.build + 'styles'));

	const fontData = gulp.src(gulpConfig.fonts)
		.pipe(gulp.dest(gulpConfig.build + 'styles/fonts'));

	const sassStyles = gulp.src(gulpConfig.styles + 'style.sass')
		.pipe($.sass().on('error', $.sass.logError))
		.pipe($.autoprefixer({
			browsers: ['last 2 version'],
			cascade: true
		}))
		.pipe(gulp.dest(gulpConfig.build + 'styles'));

	return merge(vendorStyles, fontData, sassStyles);
});

// process and compile all script files
gulp.task('build:scripts', function() {
	gulp.src(gulpConfig.jsLibs)
		.pipe($.plumber(plumberErrorHandler))
		.pipe($.concat('vendor.js'))
		.pipe(gulp.dest(gulpConfig.build + 'scripts'));

	return $.merge(
		// compile templates and include in template cache
		gulp.src([
			gulpConfig.scripts + '**/*.html'
		])
			.pipe($.angularTemplatecache('templates.js', {
				root: 'templates/',
				module: 'app.templates',
				standalone: true
			})),
		gulp.src(gulpConfig.js)
	)
		.pipe($.plumber(plumberErrorHandler))
		.pipe($.concat('script.js'))
		.pipe($.babel({
			presets: ['es2015'],
			compact: true
		}))
		.pipe($.if(production, $.ngAnnotate()))
		.pipe($.if(production, $.stripDebug()))
		.pipe($.if(production, $.uglify({
			mangle: true
		})))
		.pipe(gulp.dest(gulpConfig.build + 'scripts'));
});

// copy images
gulp.task('build:images', function() {
	const imgSrc = gulpConfig.app +  'images/**/*',
		imgDst = gulpConfig.build + 'images';

	gulp.src(imgSrc)
		.pipe(gulp.dest(imgDst));
});

// process language files
gulp.task('build:i18n', function() {
	return gulp.src(gulpConfig.app + 'i18n/*.yaml')
		.pipe($.plumber(plumberErrorHandler))
    .pipe($.yaml())
		.pipe($.declare({
			namespace: 'Translations',
			noRedeclare: false,
			root: 'window'
		}))
		.pipe($.concat('translations.js'))
		.pipe(gulp.dest(gulpConfig.build + 'scripts/'));
});

// copy html files
gulp.task('helper:pre-process', function() {
	return gulp
		.src(gulpConfig.app + 'index.html')
		.pipe(gulp.dest(gulpConfig.build));
});

// set production to true
gulp.task('helper:activate-production-env', function() {
	production = true;
});

// start api loader to provide API routes to the client
let apiProcess;
gulp.task('api:loader', function() {
	apiProcess = spawn('node', ['server.js']);

	apiProcess.stdout.on('data', (data) => {
		$.util.log(`${data}`);
	});

	apiProcess.stderr.on('data', (data) => {
		$.util.log(`grep stderr: ${data}`);
	});

	apiProcess.on('close', code => {
		if (code !== 0) {
			$.util.log(`grep process exited with code ${code}`);
		}
	});
});

// start development web server
let webserverStream;
gulp.task('run:webserver', function() {
	let targetAddress = production ?
		'http://localhost:8091' : 'http://localhost:10010';

	webserverStream = gulp.src(gulpConfig.build)
		.pipe($.webserver({
			livereload: true,
			// open: '/',
			port: 8000,
			proxies: [
				{ source: '/_api', target: targetAddress }
			]
		}));

	return webserverStream;
});

/****************************************************************************************************/
/* GULP TASK SUITES                                                                                 */
/****************************************************************************************************/

// list the available gulp tasks
gulp.task('help', $.taskListing);

// serve the current application state
gulp.task('live',
	function () {
		$.sequence('run:cqa', ['api:loader', 'helper:pre-process', 'build:i18n', 'build:scripts', 'build:styles', 'build:images', 'run:webserver'])();

		(function() {
			// watch for script changes
			gulp.watch([gulpConfig.scripts + '**/*.js'], ['run:cqa', 'build:scripts'], onModification);
			// watch for angular template changes
			gulp.watch([gulpConfig.scripts + '**/*.html'], ['build:scripts'], onModification);
			// watch for style changes
			gulp.watch([gulpConfig.scripts + '**/*.s+(a|c)ss', gulpConfig.styles + '**/*.s+(a|c)ss'], ['build:styles'], onModification);
			// watch for html changes
			gulp.watch([gulpConfig.app + '*.html'], ['helper:pre-process'], onModification);

			function onModification (event) {
				gulp.src(event.path)
					.pipe($.plumber())
					.pipe($.notify({
						title: notifyInfo.title,
						icon: notifyInfo.icon,
						message: event.path.replace(__dirname, '').replace(/\\/g, '/') + ' was ' + event.type + '.'
					}));
			}
		})();
	}
);

// start the front end with a back end running on localhost
gulp.task('serve', ['helper:activate-production-env', 'helper:pre-process', 'build:i18n', 'build:scripts', 'build:styles', 'build:images', 'run:webserver']);

// build front end for production environment (minify & uglify source files)
gulp.task('build',
	$.sequence('run:cqa', 'helper:activate-production-env', ['helper:pre-process', 'build:i18n', 'build:scripts', 'build:styles', 'build:images'])
);

// run tests
gulp.task('test',	['run:cqa'],
	function() {
		const Server = new KarmaServer({
			configFile: __dirname + '/karma.conf.js',
			singleRun: true
		}, function(exitCode) {
			process.exit(exitCode);
		});

		Server.start();
	}
);

gulp.task('e2e-test',	['api:loader', 'run:webserver'],
	function(done) {
		gulp.src('test/**/*.spec.js', { read: false })
			.pipe($.plumber())
			.pipe($.spawnMocha({}))
			.on('error', () => {
				apiProcess.kill();
				webserverStream.emit('kill');
				done();
			})
			.pipe($.exit());
	}
);

// run tests on jenkins with jenkins-reporter
gulp.task('jenkins-e2e-test',	['e2e-test']);

// clean build (jenkins-build only)
gulp.task('clean', function(cb){
	  del(['build', 'reports'], cb);
	});

// copy build files to maven expected target
gulp.task('prepare-for-maven-war', function(){
  return gulp.src(['./build/**', './war-resources/**'])
    .pipe(gulp.dest('target/gulp'));
	});