# sl-online
Das Frontend für SL-Online.

## UI Testing mit Selenium
Um End-to-End UI Tests durchführen zu können, müssen einige Voraussetzungen erfüllt sein, damit Selenium
seinen Dienst verrichtet.

*die neuste Version aller notwendigen WebDriver installieren
*das Verzeichnis, wo alle WebDriver liegen, in der Pfad Variable hinterlegen
*die aktuellsten Browser installieren

Falls die in diesem Projekt hinterlegten WebDriver verwendet werden, sollten die folgenden Browser-Versionen
installiert sein:
*Chrome 56.0.2924.87
*Firefox 52.0.2

Um die Tests zu starten muss Mocha global installiert sein. Zusätzlich muss die Applikation lokal verfügbar sein.
```
gulp serve
mocha test/**/*.spec.js
```