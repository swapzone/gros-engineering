'use strict';

process.env.DEBUG = 'api:*';
process.chdir(__dirname);

process.on('uncaughtException', () => {
	console.log('API already started. Not starting again.');
});

let fs          = require('fs');
let express	    = require('express');
let bodyParser  = require('body-parser');

let server	= express();

// parse application/json
server.use(bodyParser.json());

// initialize mock objects for all available routes
const calculationCategoriesMock = require('./mock/calculation-categories.json');
const calculationObjectsMock = require('./mock/calculation-objects.json');
const contractsMock = require('./mock/contracts.json');
const profileMock = require('./mock/user-profile.json');
const usersMock = require('./mock/users.json');

const _self = this;
_self.agbAccepted = true;
_self.authenticated = true;

// enable Express' case-sensitive and strict options
server.enable('case sensitive routing');
server.enable('strict routing');

// route implementations
server.get('/agb/version', function(req, res) {
	res.send('1');
});

server.get('/agb/1/content', function(req, res) {
	res.send('<span>Wichtige AGBs</span>');
});

server.get('/api/calculation/categories/', function(req, res) {
	res.json(calculationCategoriesMock);
});

server.get('/api/calculation/objects/', function(req, res) {
	res.json(calculationObjectsMock);
});

server.get('/api/contracts', function(req, res) {
	let offset = parseInt(req.query.offset, 10);
	let pageSize = parseInt(req.query.pageSize, 10);
	setTimeout(() => {
		res.json({
			numberOfItems: contractsMock.length,
			contracts: contractsMock.slice(offset, offset + pageSize)
		});
	}, 800);
});

server.get('/api/admin/users', function(req, res) {
	res.json(usersMock);
});

server.get('/api/profile', function(req, res) {
	if (_self.agbAccepted) {
		setTimeout(() => {
			res.json(profileMock);
		}, 300);
	} else if(_self.authenticated) {
		res.sendStatus(403);
	} else {
		res.sendStatus(401);
	}
});

server.get('/test/:parameter', function (req, res) {
	res.sendStatus(200);
});

server.post('/login', function(req, res) {
	setTimeout(() => {
		_self.authenticated = true;

		// res.status(500).send();

		res.json({
			accountInfo: {
				roles: ['ROLE_USER', 'ROLE_USERADMIN', 'ROLE_FACHADMIN'],
				username: 'Test User',
				agbStatus: 'ACCEPTED'
			},
			token: 'FakeToken'
		});
	}, 600);
});

server.post('/api/calculation/calculate', function(req, res) {
	setTimeout(() => {
		// res.sendStatus(500);
		res.json({
			monthlyRate: '1.230,40'
		});
	}, 1200);
});

server.post('/api/contracts/:parameter/claimReport', function(req, res) {
	setTimeout(() => {
		res.sendStatus(200);
	}, 1200);
});

server.post('/api/contracts/:parameter/document', function(req, res) {
	setTimeout(() => {
		res.json([]);
	}, 800);
});

server.post('/api/profile', function(req, res) {
	setTimeout(() => {
		res.sendStatus(200);
	}, 300);
});

server.post('/api/profile/agb/:agbVersion', function(req, res) {
	setTimeout(() => {
		_self.agbAccepted = true;
		res.sendStatus(200);
	}, 300);
});

server.post('/api/admin/users/:userId/:action', function(req, res) {
	let userId = parseInt(req.params.userId, 10);
	let action = req.params.action;
	setTimeout(() => {
		if (action === 'claim') {
			res.status(200).json(usersMock.filter(user => parseInt(user.id, 10) === userId)[0]);
		} else {
			res.sendStatus(200);
		}
	}, 300);
});

// logging endpoint
server.post('/log', function(req, res) {
	const fileName = './logging/log.csv';
	let stream = fs.createWriteStream(fileName, { flags: 'a' });
	stream.once('open', () => {
		stream.write(req.body.message + '\n');
		stream.end();
		res.sendStatus(200);
	});
});

server.get('/secret', function(req, res) {
	res.sendStatus(401);
});

// add a custom error handler
server.use(function(err, req, res) {
	setTimeout(() => {
		res.status(err.status).send(err.message);
	}, 800);
});

// start listening on port 10010
server.listen(10010);
