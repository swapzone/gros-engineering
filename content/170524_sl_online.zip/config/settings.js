window.SL_ONLINE_BACKEND_URL = 'http://maeld02:8021/slonline/';
window.SL_ONLINE_LANGUAGE = 'de_DE';
window.SL_ONLINE_CONTACT_SUBJECTS = [
	'Technisches Problem',
	'Mein SüdLeasing Zugang',
	'Meine Verträge',
	'Fragen zur Kalkulation',
	'Sonstiges'
];