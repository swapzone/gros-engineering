(function (angular, window) {

	'use strict';

	angular
		.module('app.api', [
			'ngFileUpload'
		])
		.constant('BACKEND', {
			url: window.SL_ONLINE_BACKEND_URL || 'http://localhost:8000/_api/'
		});
})(window.angular, window);

