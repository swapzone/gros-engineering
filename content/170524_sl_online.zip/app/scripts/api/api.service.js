(function (angular, moment) {

	'use strict';

	angular
		.module('app.api')
		.service('apiService', apiService);

	/* @ngInject */
	function apiService($log, $http, $q, Upload, BACKEND) {
		const service = this;

		/**
		 * Authenticate the user on the server.
		 *
		 * @param username
		 * @param password
		 * @param adminLogin
		 * @returns {*}
		 */
		let authenticate = (username, password, adminLogin) => {
			return $q((resolve, reject) => {
				const payload = {
					username: username,
					password: password
				};

				let loginUrl = BACKEND.url + 'login';
				if (adminLogin) {
					loginUrl += 'Admin';
				}

				$http.post(loginUrl, payload, {
					showWaitingSpinner: true
				})
					.then(result => {
						resolve(result.data);
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Retrieve content of AGB with given version number in HTML format.
		 *
		 * @param version
		 * @returns {*}
		 */
		let getAgbContent = version => {
			return $q((resolve, reject) => {
				$http.get(BACKEND.url + 'agb/' + version + '/content', {
					showWaitingSpinner: true
				}).then(response => {
					resolve(response.data);
				}, reason => {
					reject(reason.data);
				});
			});
		};

		/**
		 * Get the version number of the latest AGBs.
		 *
		 * @returns {*}
		 */
		let getAgbVersion = () => {
			return $q((resolve, reject) => {
				$http.get(BACKEND.url + 'agb/version', {
					showWaitingSpinner: true
				}).then(response => {
					resolve(response.data);
				}, reason => {
					reject(reason.data);
				});
			});
		};

		/**
		 * Get the contract document data from the back end.
		 *
		 * @param contract
		 * @returns {*}
		 */
		let getContractDocuments = contract => {
			return $q((resolve, reject) => {
				$http.get(BACKEND.url + 'api/contracts/' + contract.id + '/document', {
					showWaitingSpinner: true
				}).then(response => {
					resolve(response.data);
				}, reason => {
					reject(reason.data);
				});
			});
		};

		/**
		 * Get all available contracts for the given user.
		 *
		 * @param offset
		 * @param pageSize
		 * @param query
		 * @param sortField
		 * @param filters
		 * @returns {*}
		 */
		let getContracts = (offset, pageSize, query, sortField, filters) => {
			if (!offset) {
				offset = 0;
			}
			if (!pageSize) {
				pageSize = 10;
			}

			return $q((resolve, reject) => {
				let url = BACKEND.url + 'api/contracts?offset=' + offset + '&pageSize=' + pageSize;
				if (query) {
					url += '&q=' + query;
				}
				if (sortField) {
					url += '&sort=' + sortField;
				}
				if (filters) {
					let filterString = '&filter=\'';
					let filterArray = [];
					for (let filter in filters) {
						if (filters.hasOwnProperty(filter)) {
							filterArray.push(filter + ':' + filters[filter]);
						}
					}

					if (filterArray.length) {
						url += filterString + filterArray.join('|') + '\'';
					}
				}

				$http.get(url, {
					showWaitingSpinner: true
				})
					.then(response => {
						resolve({
							numberOfItems: response.data.numberOfItems,
							contracts: response.data.contracts.map(contract => {
								return {
									id: contract.id,
									contractNumber: contract.contractNumber,
									subContractNumber: contract.subContractNumber,
									status: contract.status,
									type: contract.type,
									startDate: moment(contract.startDate),
									endDate: moment(contract.endDate),
									description: contract.description,
									iban: contract.iban
								};
							})
						});
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Retrieve a list of all leasing categories from the server.
		 *
		 * @returns {*}
		 */
		let getLeasingCategories = () => {
			$log.debug(BACKEND.url);

			return $q((resolve, reject) => {
				$http.get(BACKEND.url + 'api/calculation/categories/', {
					showWaitingSpinner: true
				})
					.then(categories => {
						resolve(categories.data);
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Retrieve a list of all leasing objects from the server.
		 *
		 * @returns {*}
		 */
		let getLeasingObjects = () => {
			return $q((resolve, reject) => {
				$http.get(BACKEND.url + 'api/calculation/objects/', {
					showWaitingSpinner: true
				})
					.then(objects => {
						resolve(objects.data);
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Retrieve and cache user information from back end.
		 *
		 * @returns {*}
		 */
		let getUserInformation = () => {
			if (service.userInformationRequested) {
				return service.userInformationRequested;
			}
			service.userInformationRequested = $q((resolve, reject) => {
				if (service.userInformation) {
					$log.debug('Serving cached user information.');
					resolve(service.userInformation);
				} else {
					$http.get(BACKEND.url + 'api/profile', {
						showWaitingSpinner: true
					})
						.then(response => {
							service.userInformation = response.data;
							resolve(response.data);
						}, reason => {
							service.userInformationRequested = undefined;
							reject(reason.data);
						});
				}
			});

			return service.userInformationRequested;
		};

		/**
		 * Retrieve all users from back end.
		 *
		 * @returns {*}
		 */
		let getUsers = () => {
			return $q((resolve, reject) => {
				$http.get(BACKEND.url + 'api/admin/users', {
					showWaitingSpinner: true
				})
					.then(objects => {
						resolve(objects.data);
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Trigger a well-defined account action on the user account of the given
		 * user.
		 *
		 * @param userId
		 * @param action
		 * @param payload optional
		 * @returns {*}
		 */
		let postAccountAction = (userId, action, payload) => {
			if (['enable', 'lock', 'reset', 'claim', 'unclaim', 'delete'].indexOf(action) === -1) {
				throw Error('User account action is not valid.');
			}

			if (!payload) {
				payload = {};
			}

			return $q((resolve, reject) => {
				if (action === 'reset') {
					$http.post(BACKEND.url + 'reset', payload, {
						showWaitingSpinner: true
					}).then(resolve, reject);
				} else {
					$http.post(BACKEND.url + 'api/admin/users/' + userId + '/' + action, payload, {
						showWaitingSpinner: true
					}).then(response => {
						resolve(response.data);
					}, reject);
				}
			});
		};

		/**
		 * Sends a request to the server asking for a calculation value based on
		 * the given form data.
		 *
		 * @param userData
		 * @param formData
		 * @returns {*}
		 */
		let postCalculationRequest = (userData, formData) => {
			return $q((resolve, reject) => {
				const payload = {
					userId: userData.id,
					categoryId: formData.subCategory.id,
					contractType: formData.contractType,
					dateBuilt: formData.dateBuilt,
					downPayment: {
						value: parseInt(formData.downPayment.value, 10),
						type: formData.downPayment.type
					},
					duration: parseInt(formData.duration, 10),
					investment: parseInt(formData.investment, 10),
					objectCondition: formData.objectCondition || 'new',
					objectDetails: formData.objectDetails,
					recoveryValue: {
						value: parseInt(formData.recoveryValue.value, 10),
						type: formData.recoveryValue.type
					},
					withVat: formData.investmentTaxable
				};

				$http.post(BACKEND.url + 'api/calculation/calculate', payload, {
					showWaitingSpinner: true
				})
					.then(result => {
						resolve(result.data);
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Change the password of the authenticated user.
		 *
		 * @param oldPassword
		 * @param newPassword
		 * @returns {*}
		 */
		let postChangePassword = (oldPassword, newPassword) => {
			return $q((resolve, reject) => {
				$http.post(BACKEND.url + 'api/changePassword', {
					oldPassword: oldPassword,
					newPassword: newPassword
				}, {
					showWaitingSpinner: true
				})
					.then(() => {
						resolve();
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Send contact request to back end.
		 *
		 * @param request
		 * @returns {*}
		 */
		let postContactRequest = request => {
			return $q((resolve, reject) => {
				$http.post(BACKEND.url + 'contact', request, {
					showWaitingSpinner: true
				})
					.then(() => {
						resolve();
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * The user can trigger contract actions like cancel, extend,
		 * balanceAcknowledgement or claimReport with a given actionPayload for a
		 * given contractNumber.
		 *
		 * @param contractNumber
		 * @param actionType
		 * @param actionPayload
		 * @returns {*}
		 */
		let postContractAction = (contractNumber, actionType, actionPayload) => {
			const actionTypes = [
				'cancel', 'extend', 'balanceAcknowledgement', 'claimReport', 'bankAccount'
			];

			if (actionTypes.indexOf(actionType) === -1) {
				throw Error('The actionType is not supported by the REST API.');
			}

			$log.debug('Send ' + actionType + ' contract request for contract ' + contractNumber);

			return $q((resolve, reject) => {
				const url = BACKEND.url + 'api/contracts/' + contractNumber + '/' + actionType;
				$http.post(url, actionPayload, {
					showWaitingSpinner: true
				}).then(resolve, reject);
			});
		};

		/**
		 * Send log message to back end.
		 *
		 * @param message
		 * @returns {*}
		 */
		let postLogMessage = message => {
			return $q(resolve => {
				const payload = {
					message: message
				};

				$http.post(BACKEND.url + 'log', payload, {
					showWaitingSpinner: false
				}).then(resolve, err => {
					$log.warn('Could not log message:');
					$log.warn(err);
				});
			});
		};

		/**
		 * Send quote request to back end.
		 *
		 * @param userData
		 * @param formData
		 * @param files
		 * @returns {*}
		 */
		let postQuoteRequest = (userData, formData, files) => {
			return $q((resolve, reject) => {
				const payload = {
					userId: userData.id,
					categoryId: formData.subCategory.id,
					contractType: formData.contractType,
					dateBuilt: formData.dateBuilt,
					downPayment: {
						value: parseInt(formData.downPayment.value, 10),
						type: formData.downPayment.type
					},
					duration: parseInt(formData.duration, 10),
					investment: parseInt(formData.investment, 10),
					objectCondition: formData.objectCondition || 'new',
					objectDetails: formData.objectDetails,
					recoveryValue: {
						value: parseInt(formData.recoveryValue.value, 10),
						type: formData.recoveryValue.type
					},
					withVat: formData.investmentTaxable
				};

				Upload.upload({
					url: BACKEND.url + 'api/calculation/quote',
					data: {
						file: files,
						data: payload
					},
					headers: {
						accept: 'application/json'
					}
				}).success(() => {
					resolve();
				}).error(reject);

				// $http.post(BACKEND.url + 'api/calculation/quote', payload, {
				// 	showWaitingSpinner: true
				// })
				// 	.then(() => {
				// 		resolve();
				// 	}, reject);
			});
		};

		/**
		 * Update user data on the server.
		 *
		 * @param userUpdateData
		 * @returns {*}
		 */
		let postUserData = (userUpdateData) => {
			return $q((resolve, reject) => {
				$http.post(BACKEND.url + 'api/profile', userUpdateData, {
					showWaitingSpinner: true
				})
					.then(() => {
						resolve();
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Update only AGB aspect of user data.
		 *
		 * @param agbVersion
		 * @returns {*}
		 */
		let postUserDataAGBsAccepted = (agbVersion) => {
			return $q((resolve, reject) => {
				$http.post(BACKEND.url + 'api/profile/agb/' + agbVersion, {
					showWaitingSpinner: true
				})
					.then(() => {
						resolve();
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Register a new user.
		 *
		 * @param username
		 * @param password
		 * @param firstname
		 * @param lastname
		 * @param email
		 * @param contractNumber
		 * @param company
		 * @returns {*}
		 */
		let register = (username, password, firstname, lastname, email, contractNumber, company) => {
			return $q((resolve, reject) => {
				const payload = {
					username: username,
					password: password,
					company: company,
					firstName: firstname,
					lastName: lastname,
					mail: email,
					contractNumber: contractNumber
				};

				$http.post(BACKEND.url + 'register', payload, {
					showWaitingSpinner: true
				})
					.then((result) => {
						resolve(result.data);
					}, reason => {
						reject(reason.data);
					});
			});
		};

		/**
		 * Replace the password on the server with the given one.
		 *
		 * @param password
		 * @param hash
		 * @returns {*}
		 */
		let resetPassword = (password, hash) => {
			return $q((resolve, reject) => {
				const payload = {
					password: password,
					verification: hash
				};

				$http.post(BACKEND.url + 'resetPassword', payload, {
					showWaitingSpinner: true
				}).then(resolve, reason => {
					reject(reason.data);
				});
			});
		};

		/**
		 * Uploads the given configuration file to the server.
		 *
		 * @param userId
		 * @param file
		 * @returns {*}
		 */
		let uploadApplicationObjectFile = (userId, file) => {
			return $q((resolve, reject) => {
				Upload.upload({
					url: BACKEND.url + 'api/config/upload',
					data: {
						file: file
					},
					headers: {
						accept: 'application/json'
					}
				}).success(() => {
					$log.debug('Application Object File uploaded!');
					resolve();
				}).error(reject);
			});
		};

		/**
		 * Uploads the given files to the server.
		 *
		 * @param userId
		 * @param files
		 * @param metaData
		 * @returns {*}
		 */
		let uploadFiles = (userId, files, metaData) => {
			return $q((resolve, reject) => {
				Upload.upload({
					url: BACKEND.url + 'api/upload',
					data: {
						file: files,
						meta: metaData
					},
					headers: {
						accept: 'application/json'
					}
				}).success(() => {
					resolve();
				}).error(reject);
			});
		};

		//
		// Service API
		//
		service.authenticate = authenticate;
		service.getAgbContent = getAgbContent;
		service.getAgbVersion = getAgbVersion;
		service.getContractDocuments = getContractDocuments;
		service.getContracts = getContracts;
		service.getLeasingCategories = getLeasingCategories;
		service.getLeasingObjects = getLeasingObjects;
		service.getUserInformation = getUserInformation;
		service.getUsers = getUsers;
		service.postAccountAction = postAccountAction;
		service.postCalculationRequest = postCalculationRequest;
		service.postChangePassword = postChangePassword;
		service.postContactRequest = postContactRequest;
		service.postContractAction = postContractAction;
		service.postLogMessage = postLogMessage;
		service.postQuoteRequest = postQuoteRequest;
		service.postUserData = postUserData;
		service.postUserDataAGBsAccepted = postUserDataAGBsAccepted;
		service.register = register;
		service.resetPassword = resetPassword;
		service.uploadApplicationObjectFile = uploadApplicationObjectFile;
		service.uploadFiles = uploadFiles;
	}
})(window.angular, window.moment);

