(function (angular, jasmine) {

	'use strict';

	describe('Module: app.api', () => {
		describe('Component: apiService', () => {
			let $log;
			let $http;
			let $q;
			let $rootScope;
			let $httpBackend;
			let apiService;

			// first inject the module to test
			beforeEach(module('app.api'));
			// then manually provide the constants / services
			beforeEach(() => {
				module($provide => {
					$provide.constant('BACKEND', {
						url: 'http://localhost/_api/'
					});
				});
			});
			// then use the automated injector to inject all required services
			beforeEach(angular.mock.inject((_$log_, _$http_, _$q_, _$rootScope_, _$httpBackend_, _apiService_) => {
				$log = _$log_;
				$http = _$http_;
				$q = _$q_;
				$rootScope = _$rootScope_;
				$httpBackend = _$httpBackend_;
				apiService = _apiService_;
			}));

			afterEach(() => {
				$httpBackend.verifyNoOutstandingExpectation();
				$httpBackend.verifyNoOutstandingRequest();
			});

			it('should inject the mocked constant', () => {
				spyOn($log, 'debug');
				spyOn($http, 'get').and.returnValue($q.resolve({ data: [] }));
				let result = apiService.getLeasingCategories();

				expect($log.debug).toHaveBeenCalledWith('http://localhost/_api/');

				result
					.catch(reason => {
						expect(reason).toBe('Not yet implemented.');
					});
			});

			it('should call the right URL for a login call', () => {
				// important is to use callThrough to let $http do its business
				spyOn($http, 'post').and.callThrough();

				$httpBackend
					.when('POST', 'http://localhost/_api/login')
					.respond(200, { token: 'testtoken' });

				let result = apiService.authenticate('user', '1234');
				$httpBackend.flush();

				expect($http.post).toHaveBeenCalledWith(
					'http://localhost/_api/login', jasmine.any(Object), jasmine.any(Object));

				result
					.then(response => {
						expect(response.token).toBe('testtoken');
					});
			});

			it('should call the right URL for a contact request call', () => {
				spyOn($http, 'post').and.callThrough();

				$httpBackend
					.when('POST', 'http://localhost/_api/contact')
					.respond(200);

				let result = apiService.postContactRequest({ test: 'test' });
				$httpBackend.flush();

				expect($http.post).toHaveBeenCalledWith(
					'http://localhost/_api/contact', { test: 'test' }, jasmine.any(Object));

				result
					.then(response => {
						// nothing will be returned from the function
						expect(response).toBeUndefined();
					});
			});

			it('should call the right URL for a user registration call', () => {
				spyOn($http, 'post').and.callThrough();

				const registrationData = {
					username: 'test',
					password: 'password',
					company: 'Test Firma',
					firstName: undefined,
					lastName: undefined,
					mail: undefined,
					contractNumber: undefined
				};

				$httpBackend
					.when('POST', 'http://localhost/_api/register')
					.respond(200, { data: { test: 'wow' } });

				let result = apiService.register('test', 'password', undefined, undefined, undefined, undefined, 'Test Firma');
				$httpBackend.flush();

				expect($http.post).toHaveBeenCalledWith(
					'http://localhost/_api/register', registrationData, jasmine.any(Object));

				result
					.then(response => {
						// nothing will be returned from the function
						expect(response.data.test).toBe('wow');
					});
			});

			it('should call the right URL for a update user data call', () => {
				spyOn($http, 'post').and.callThrough();

				$httpBackend
					.when('POST', 'http://localhost/_api/api/profile')
					.respond(200);

				let result = apiService.postUserData({ test: 'user' });
				$httpBackend.flush();

				expect($http.post).toHaveBeenCalledWith(
					'http://localhost/_api/api/profile', { test: 'user' }, jasmine.any(Object));

				result
					.then(response => {
						// nothing will be returned from the function
						expect(response).toBeUndefined();
					});
			});
		});
	});
})(window.angular, window.jasmine);
