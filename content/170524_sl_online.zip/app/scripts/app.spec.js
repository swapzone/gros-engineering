(function () {

	'use strict';

	describe('Test Runner', () => {
		it('should run this test successfully', () => {
			expect(true).toBeTruthy();
		});
	});
})();
