(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.factory('Roles', rolesFactory);

	/* @ngInject */
	function rolesFactory(ROLES) {

		/**
		 * Constructor function for User object.
		 *
		 * @param roles
		 * @constructor
		 */
		function Roles(roles) {
			this.roles = roles;
		}

		// Static property
		Roles.availableRoles = angular.copy(ROLES);

		/**
		 * Returns true, if the roles include an admin role.
		 *
		 * @returns {boolean}
		 */
		Roles.prototype.isAdministrator = function () {
			const adminRoles = [
				Roles.availableRoles.admin.tech,
				Roles.availableRoles.admin.user,
				Roles.availableRoles.admin.impersonated
			];

			for (let i = 0; i < this.roles.length; i++) {
				if (adminRoles.indexOf(this.roles[i]) > -1) {
					return true;
				}
			}

			return false;
		};

		/**
		 * Returns true, if the roles include the user role.
		 *
		 * @returns {boolean}
		 */
		Roles.prototype.isUser = function () {
			for (let i = 0; i < this.roles.length; i++) {
				if (ROLES.user === this.roles[i]) {
					return true;
				}
			}
			return false;
		};

		/**
		 * Static method, assigned to class.
		 * Instance ('this') is not available in a static context.
		 *
		 * @param roles
		 * @returns {Roles}
		 */
		Roles.build = function (roles) {
			if (!roles) {
				roles = [];
			}
			return new Roles(roles);
		};

		// return constructor function
		return Roles;
	}
})(window.angular);
