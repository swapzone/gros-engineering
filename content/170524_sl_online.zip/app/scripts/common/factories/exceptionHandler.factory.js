(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.factory('$exceptionHandler', $exceptionHandler);

	/* @ngInject */
	function $exceptionHandler($log) {
		return (exception, cause) => {

			// TODO implement custom exception handler
			// logErrorsToBackend(exception, cause);

			$log.warn('Custom Exception Handler:');
			$log.warn(exception, cause);
		};
	}
})(window.angular);
