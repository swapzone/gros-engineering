(function (angular) {

	'use strict';

	describe('Module: app.common', () => {
		describe('Component: sessionService', () => {
			let sessionService;
			let $localStorage;
			let $sessionStorage;

			beforeEach(module('app.common'));
			beforeEach(angular.mock.inject((_$localStorage_, _$sessionStorage_, _sessionService_) => {
				$localStorage = _$localStorage_;
				$sessionStorage = _$sessionStorage_;
				sessionService = _sessionService_;
			}));

			it('should have no token set initially', () => {
				expect(sessionService.getAuthenticationToken()).toBeUndefined();
			});

			it('should store the token to the session storage', () => {
				sessionService.storeAuthenticationToken('TestToken');
				expect($sessionStorage['sl-user-token']).toBe('TestToken');
				expect($localStorage['sl-user-token']).toBeUndefined();
			});

			it('should store the token to the local storage', () => {
				sessionService.storeAuthenticationToken('TestToken', true);
				expect($sessionStorage['sl-user-token']).toBe('TestToken');
				expect($localStorage['sl-user-token']).toBe('TestToken');
			});

			it('should return true if a token is available', () => {
				sessionService.storeAuthenticationToken('TestToken');
				expect(sessionService.isAuthenticated()).toBeTruthy();
			});

			it('should remove the access token both from local and session storage', () => {
				sessionService.storeAuthenticationToken('TestToken', true);
				sessionService.removeAuthenticationToken();
				expect($sessionStorage['sl-user-token']).toBeUndefined();
				expect($localStorage['sl-user-token']).toBeUndefined();
			});
		});
	});
})(window.angular);
