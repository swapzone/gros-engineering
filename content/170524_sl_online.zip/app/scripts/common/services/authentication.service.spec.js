(function (angular) {

	'use strict';

	describe('Module: app.common', () => {
		describe('Component: authenticationService', () => {
			let apiService;
			let sessionService;
			let authenticationService;
			let $http;
			let $q;

			beforeEach(module('app.common'));
			beforeEach(angular.mock.inject((_$http_, _$q_, _apiService_, _sessionService_, _authenticationService_) => {
				$http = _$http_;
				$q = _$q_;
				apiService = _apiService_;
				sessionService = _sessionService_;
				authenticationService = _authenticationService_;
			}));

			it('should store the authentication token and the user profile', () => {
				spyOn(apiService, 'authenticate').and.returnValue($q.resolve({
					token: 'test',
					accountInfo: {}
				}));
				spyOn(sessionService, 'storeAuthenticationToken');

				let result = authenticationService.login('user', 'password');

				result.then(() => {
					expect(sessionService.storeAuthenticationToken).toHaveBeenCalledWith('test');
				});
			});

			it('should set the authentication token into the $http header', () => {
				spyOn(apiService, 'authenticate').and.returnValue($q.resolve({
					token: 'test',
					accountInfo: {}
				}));

				let result = authenticationService.login('user', 'password');

				result.then(() => {
					expect($http.defaults.headers.common.hasOwnProperty('jwt-token')).toBeTruthy();
					expect($http.defaults.headers.common['jwt-token']).toBe('test');
				});
			});

			it('should delete the authentication token and the user profile', () => {
				spyOn(sessionService, 'removeAuthenticationToken');

				authenticationService.logout();

				expect(sessionService.removeAuthenticationToken).toHaveBeenCalled();
			});

			it('should delete the authentication token from the request header', () => {
				authenticationService.logout();

				expect($http.defaults.headers.common.hasOwnProperty('jwt-token')).toBeFalsy();
			});
		});
	});
})(window.angular);
