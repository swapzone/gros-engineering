(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('tooltip', {
			controller: TooltipController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/tooltip/tooltip.html',
			bindings: {
				text: '@'
			}
		});

	/* @ngInject */
	function TooltipController($log, $timeout) {
		const vm = this;

		let tooltipTimer = null;

		vm.$onInit = () => {};

		/**
		 * Hide tooltip.
		 */
		let closeTooltip = () => {
			if (tooltipTimer) {
				$timeout.cancel(tooltipTimer);
			}

			vm.showTooltip = false;
		};

		/**
		 * Show tooltip.
		 */
		let openTooltip = () => {
			$log.debug('Show tooltip');

			if (tooltipTimer) {
				$timeout.cancel(tooltipTimer);
			}

			vm.showTooltip = true;

			tooltipTimer = $timeout(() => {
				vm.showTooltip = false;
			}, 3500);
		};

		//
		// Controller API
		//
		vm.closeTooltip = closeTooltip;
		vm.openTooltip = openTooltip;
	}
})(window.angular);

