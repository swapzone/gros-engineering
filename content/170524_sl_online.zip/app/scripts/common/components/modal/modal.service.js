(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.service('modalService', modalService);

	/* @ngInject */
	function modalService($q, $rootScope) {
		const service = this;

		let modal = {
			deferred: null,
			params: null
		};

		/**
		 * Open a new modal with the given parameters.
		 *
		 * @param type
		 * @param params
		 * @returns {*}
		 */
		let open = (type, params) => {
			modal.deferred = $q.defer();
			modal.params = params;

			if (type !== undefined) {
				modal.params.templateUrl = 'templates/common/components/modal/views/' + type + '.html';
			}

			$rootScope.$emit('modals.open', type);
			return modal.deferred.promise;
		};

		/**
		 * Get parameters for current modal.
		 *
		 * @returns {*}
		 */
		let params = () => {
			return modal.params;
		};

		/**
		 * Reject the current modal.
		 *
		 * @param reason
		 */
		let reject = (reason) => {
			if (!modal.deferred) {
				return;
			}
			modal.deferred.reject(reason);
			modal.deferred = modal.params = null;

			$rootScope.$emit('modals.close');
		};

		/**
		 * Resolve the current modal.
		 *
		 * @param response
		 */
		let resolve = (response) => {
			if (!modal.deferred) {
				return;
			}
			modal.deferred.resolve(response);
			modal.deferred = modal.params = null;

			$rootScope.$emit('modals.close');
		};

		//
		// Service API
		//
		service.open = open;
		service.params = params;
		service.reject = reject;
		service.resolve = resolve;
	}
})(window.angular);
