(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('mainNavigation', {
			controller: NavigationController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/navigation/navigation.html',
			bindings: {
				type: '@',
				isOpen: '<',
				user: '<',
				onMenuClose: '&'
			}
		});

	/* @ngInject */
	function NavigationController($state, authenticationService, claimedUserService, sessionService) {
		const vm = this;

		vm.$onInit = () => {
			vm.submenu = {};
		};

		/**
		 * Checks if an admin has impersonated another user.
		 *
		 * @returns {*}
		 */
		let hasClaimedUser = () => {
			return claimedUserService.hasClaimedUser();
		};

		/**
		 * Returns true, if the user has an admin role.
		 *
		 * @returns {boolean}
		 */
		let isAdministrator = () => {
			return vm.user.isAdministrator();
		};

		/**
		 * Checks if the current user is authenticated.
		 *
		 * @returns {boolean}
		 */
		let isAuthenticated = () => {
			return sessionService.isAuthenticated();
		};

		/**
		 * Checks if the menu is rendered for a mobile screen.
		 *
		 * @returns {boolean}
		 */
		let isMobileMenu = () => {
			return vm.type === 'mobile';
		};

		/**
		 * Checks if the given state is active.
		 *
		 * @param state
		 * @returns {boolean}
		 */
		let isState = state => {
			return $state.current.name === state || isChildStateActive(state);
		};

		/**
		 * Checks if a child of the given state is active.
		 *
		 * @param state
		 * @returns {boolean}
		 */
		let isChildStateActive = state => {
			return $state.current.parent === state;
		};

		/**
		 * Returns true, if the user has the user role.
		 *
		 * @returns {boolean}
		 */
		let isUser = () => {
			return vm.user.isUser();
		};

		/**
		 * Is user allowed to use the calculator.
		 *
		 * @returns {boolean}
		 */
		let isUserAllowedToCalculate = () => {
			return !!vm.user.calculationAllowed;
		};

		/**
		 * Remove the auth token from the application.
		 */
		let logout = () => {
			authenticationService.logout();
			vm.onMenuClose();
			$state.go('login');
		};

		/**
		 * Toggle the sub menu for the given state menu item.
		 *
		 * @param state
		 */
		let toggleSubmenu = state => {
			vm.submenu[state] = !vm.submenu[state];
		};

		//
		// Controller API
		//
		vm.hasClaimedUser = hasClaimedUser;
		vm.isAdministrator = isAdministrator;
		vm.isAuthenticated = isAuthenticated;
		vm.isChildStateActive = isChildStateActive;
		vm.isMobileMenu = isMobileMenu;
		vm.isState = isState;
		vm.isUser = isUser;
		vm.isUserAllowedToCalculate = isUserAllowedToCalculate;
		vm.logout = logout;
		vm.toggleSubmenu = toggleSubmenu;
	}
})(window.angular);

