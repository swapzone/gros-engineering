(function () {

	'use strict';

	describe('Module: app.common', function () {
		describe('Component: navigation', function () {

		});
	});
})();
