(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('languagePicker', {
			controller: LanguagePickerController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/translate/translate.html'
		});

	/* @ngInject */
	function LanguagePickerController($cookies, $translate) {
		const vm = this;

		vm.availableLanguages = $translate.getAvailableLanguageKeys();
		vm.showLanguagePicker = false;

		vm.$onInit = () => {
			const selectedLanguage = $cookies.get('sl_lang');
			if (selectedLanguage) {
				vm.setLanguage(selectedLanguage);
			}
		};

		/**
		 * Get currently active language.
		 *
		 * @returns {*}
		 */
		let getLanguage = () => {
			return $translate.use();
		};

		/**
		 * Checks if the given language is the active one.
		 *
		 * @param language
		 * @returns {boolean}
		 */
		let isActive = (language) => {
			return $translate.use() === language;
		};

		/**
		 * Set language for given language key.
		 *
		 * @param languageKey
		 */
		let setLanguage = (languageKey) => {
			vm.showLanguagePicker = false;
			$cookies.put('sl_lang', languageKey);
			$translate.use(languageKey);
		};

		//
		// Component API
		//
		vm.getLanguage = getLanguage;
		vm.isActive = isActive;
		vm.setLanguage = setLanguage;
	}
})(window.angular);
