(function () {

	'use strict';

	angular
		.module('app.common')
		.config(translateConfig);

	/* @ngInject */
	function translateConfig($translateProvider, $windowProvider) {
		let $window = $windowProvider.$get();
		let translations = $window.Translations;

		// only initialize translations if translation object is available
		if (typeof translations === 'object') {
			$translateProvider
				.translations('de_DE', translations.de_DE)
				.translations('en_US', translations.en_US);

			$translateProvider
				.registerAvailableLanguageKeys(['en_US', 'de_DE'], {
					'en_*': 'en_US',
					'de_*': 'de_DE'
				})
				.uniformLanguageTag('default')
				.fallbackLanguage('de_DE')
				.determinePreferredLanguage()
				.useSanitizeValueStrategy('escaped');
		}
	}
})();
