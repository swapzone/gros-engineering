(function (jasmine) {
	'use strict';

	describe('Module: app.common', function () {
		describe('Component: paging', function () {
			let $componentController;
			let controller;
			let callbackSpy;

			beforeEach(module('app.common'));
			beforeEach(angular.mock.inject(function (_$componentController_) {
				$componentController = _$componentController_;
				controller = $componentController('paging');
				callbackSpy = jasmine.createSpy('onPageChanged');
				controller.onPageChanged = callbackSpy;
			}));

			it('should deactivate the previous page control on first page', function () {
				controller.currentPage = 1;
				expect(controller.isPreviousPageControlActive()).toBeFalsy();
			});

			it('should deactivate the next page control on last page', function () {
				controller.pages = [1, 2, 3];
				controller.currentPage = 3;
				expect(controller.isNextPageControlActive()).toBeFalsy();
			});

			it('should call the onPageChanged callback on page change', function () {
				controller.currentPage = 1;
				controller.selectPage(2);
				expect(callbackSpy).toHaveBeenCalled();
			});
		});
	});
})(window.jasmine);
