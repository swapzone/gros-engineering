(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('datePicker', {
			controller: DatePickerController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/date-picker/date-picker.html',
			bindings: {
				date: '=',
				view: '@',
				minDate: '<',
				required: '<',
			}
		});

	/* @ngInject */
	function DatePickerController($log, $scope) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('DatePickerController');

			vm.datePattern = vm.view && vm.view === 'year' ?
				'\\d{2}\\/\\d{4}' : '\\d{2}\\.\\d{2}\\.\\d{4}';

			$scope.$watch('vm.date', newValue => {
				if (newValue) {
					$log.debug('Date changed: ' + newValue);
				}
			});
		};
	}
})(window.angular);

