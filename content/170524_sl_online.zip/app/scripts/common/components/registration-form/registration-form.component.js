(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.component('registrationForm', {
			controller: RegistrationFormController,
			controllerAs: 'vm',
			templateUrl: 'templates/common/components/registration-form/registration-form.html',
			bindings: {
				formData: '<',
				onFormDataChanged: '&'
			}
		});

	/* @ngInject */
	function RegistrationFormController(registrationService) {
		const vm = this;

		vm.$onInit = () => {
			vm.passwordIsValid = true;

			if (!vm.formData) {
				vm.formData = {};
			}

			if (!vm.formData.hasOwnProperty('value')) {
				vm.formData.value = {};
			}
		};

		/**
		 * Callback when form data changed.
		 *
		 * @returns {boolean}
		 */
		let formDataChanged = () => {
			if (vm.onFormDataChanged !== undefined) {
				vm.onFormDataChanged({ formData: vm.formData });
			}
		};

		/**
		 * Checks if the entered passwords are valid.
		 *
		 * @returns {boolean}
		 */
		let isPasswordValid = () => {
			formDataChanged();

			angular.extend(vm,
				registrationService.validateRegistrationData(vm.formData));

			return vm.passwordIsValid && !vm.failsPasswordCriteria;
		};

		//
		// Controller API
		//
		vm.formDataChanged = formDataChanged;
		vm.isPasswordValid = isPasswordValid;
	}
})(window.angular);

