(function (angular) {

	'use strict';

	angular
		.module('app.common')
		.service('registrationService', registrationService);

	/* @ngInject */
	function registrationService() {
		const service = this;

		function validateRegistrationData(formData) {
			if (!formData || !formData.value) {
				return {
					dataAvailable: false,
					passwordIsValid: false,
					failsPasswordCriteria: true
				};
			}

			let result = {
				dataAvailable: true,
				passwordIsValid: true,
				failsPasswordCriteria: false
			};

			result.dataAvailable = !!(
				formData.value.username && formData.value.email && formData.value.firstname &&
				formData.value.lastname && formData.value.company && formData.value.contractNumber &&
				formData.value.password && formData.value.passwordConfirm);

			result.passwordIsValid =
				!formData.value.password || !formData.value.passwordConfirm ||
				formData.value.password === formData.value.passwordConfirm;

			result.failsPasswordCriteria = formData.value.password && formData.value.password.length < 8;

			return result;
		}

		//
		// Service API
		//
		service.validateRegistrationData = validateRegistrationData;
	}
})(window.angular);
