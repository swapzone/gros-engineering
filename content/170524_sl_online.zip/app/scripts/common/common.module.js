(function (angular) {

	'use strict';

	angular
		.module('app.common', [
			'pascalprecht.translate',
			'ngCookies',
			'ngSanitize',
			'ngStorage',
			'moment-picker',
			'ui.router',
			'app.api'
		]);
})(window.angular);

