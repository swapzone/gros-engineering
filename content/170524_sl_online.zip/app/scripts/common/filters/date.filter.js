(function (angular, moment) {

	'use strict';

	angular
		.module('app.common')
		.filter('date', dateFilter);

	/* @ngInject */
	function dateFilter($log) {
		return (input, format) => {
			let result = '';

			format = format || 'DD.MM.YYYY';

			try {
				result = moment(input).format(format);
			} catch (e) {
				$log.error('Cuuld not transform date: ' + e.message);
			}

			return result;
		};
	}
})(window.angular, window.moment);
