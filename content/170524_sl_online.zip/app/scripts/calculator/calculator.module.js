(function (angular) {

	'use strict';

	angular.module('app.calculator', [
		'ui.router',
		'app.api',
		'app.common'
	]);
})(window.angular);
