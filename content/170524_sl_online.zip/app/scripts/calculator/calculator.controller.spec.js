(function (angular) {

	'use strict';

	describe('Module: app.calculator', () => {
		describe('Component: CalculatorController', () => {
			let $q;
			let $timeout;
			let apiService;

			let CalculatorController;

			const user = {
				userId: 6,
				userName: 'user',
				firstName: 'Max',
				lastName: 'Mustermann',
				email: 'max@suedleasing.com',
				companyData: {
					company: 'Test Firma',
					legalForm: 'GmbH',
					street: 'Straße 2',
					zip: '12345',
					city: 'Test Stadt',
				},
				isAdministrator: () => {
					return false;
				},
				isUser: () => {
					return true;
				}
			};
			const categoryMock = [
				{
					id: 10,
					label: 'Baumaschinen',
					subCategories: [
						{
							id: 13,
							label: 'Bagger',
							durations: [
								12,
								24,
								36,
								48,
								60
							]
						},
						{
							id: 12,
							label: 'Raupen - Kettenbagger',
							durations: [
								6,
								12,
								18,
								24,
								30
							]
						}
					]
				}
			];

			// first inject the module to test
			beforeEach(module('app.calculator'));
			// then manually provide the constants / services
			beforeEach(() => {
				module($provide => {
					$provide.constant('user', user);
				});
			});
			// then use the automated injector to inject all required services
			beforeEach(angular.mock.inject((_$controller_, _$q_, _$rootScope_, _$timeout_, _apiService_) => {
				$q = _$q_;
				$timeout = _$timeout_;
				apiService = _apiService_;

				CalculatorController = _$controller_('CalculatorController', { $scope: _$rootScope_.$new() });

				spyOn(apiService, 'getLeasingCategories').and.returnValue($q.resolve(categoryMock));
				CalculatorController.$onInit();
			}));

			it('should initialize the controller with the right data', () => {
				expect(CalculatorController.formData.objectCondition).toEqual('new');
				expect(CalculatorController.formData.contractType).toEqual('PARTIAL_AMORTISATION');
			});

			it('should retrieve the categories from the API on being initialized', () => {
				expect(apiService.getLeasingCategories).toHaveBeenCalled();
			});
		});
	});
})(window.angular);
