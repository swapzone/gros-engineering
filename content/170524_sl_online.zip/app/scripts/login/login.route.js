(function (angular) {

	'use strict';

	angular
		.module('app.login')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('login', {
			url: '/login?:admin:previous',
			parent: 'root',
			templateUrl: 'templates/login/login.html',
			controller: 'LoginController',
			controllerAs: 'vm',
			resolve: {
				/* @ngInject */
				agbVersion: (apiService) => {
					return apiService.getAgbVersion();
				}
			}
		});
	}
})(window.angular);
