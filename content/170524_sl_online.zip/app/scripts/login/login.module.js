(function (angular) {

	'use strict';

	angular.module('app.login', [
		'ui.router',
		'app.common',
		'app.api'
	]).constant('AGB_STATUS', {
		accepted: 'ACCEPTED',
		notAccepted: 'NOT_ACCEPTED',
		stale: 'STALE'
	});
})(window.angular);
