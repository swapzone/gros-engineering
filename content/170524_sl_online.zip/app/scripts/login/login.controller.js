(function (angular) {

	'use strict';

	angular
		.module('app.login')
		.controller('LoginController', LoginController);

	/* @ngInject */
	function LoginController(
		$log,
		$q,
		$rootScope,
		$state,
		$stateParams,
		$window,
		apiService,
		authenticationService,
		modalService,
		agbVersion,
		Roles,
		AGB_STATUS) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('LoginController');
			vm.loginError = undefined;

			if ($stateParams.admin !== undefined) {
				$log.debug('Admin login is active');
				vm.adminLogin = true;
			}
		};

		/**
		 * Checks if all required input is available.
		 *
		 * @returns {boolean}
		 */
		let isFormComplete = () => {
			return vm.username && vm.password;
		};

		/**
		 * Handle the AGB modal and all related data processing.
		 *
		 * @param agbStatus
		 */
		let handleAgbProcess = agbStatus => {
			let modalTitle = agbStatus === AGB_STATUS.notAccepted ?
				'AGB der SüdLeasing GmbH' : 'Die AGB der SüdLeasing GmbH haben sich geändert';

			return apiService.getAgbContent(agbVersion)
				.then(htmlContent => {
					const modalParams = {
						title: modalTitle,
						data: {
							text: {
								value: htmlContent,
								required: false
							}
						},
						confirmText: 'AGB zustimmen'
					};
					return modalService.open('business-terms', modalParams);
				})
				.catch(() => {
					return $q.reject(new Error('Sie müssen die AGB akzeptieren, um das SüdLeasing ' +
						'Online Portal nutzen zu können.'));
				})
				.then(() => {
					return apiService.postUserDataAGBsAccepted(agbVersion);
				});
		};

		/**
		 * Login handler function.
		 *
		 * @param username
		 * @param password
		 * @param remember
		 */
		let login = (username, password, remember) => {
			vm.loginError = false;
			vm.errorMessage = '';

			let roles = [];
			authenticationService.login(username, password, remember, vm.adminLogin)
				.then(result => {
					roles = result.accountInfo.roles;
					switch (result.accountInfo.agbStatus) {
						case AGB_STATUS.accepted:
							return $q.resolve();
						case AGB_STATUS.notAccepted:
							return handleAgbProcess(AGB_STATUS.notAccepted);
						case AGB_STATUS.stale:
							return handleAgbProcess(AGB_STATUS.stale);
						default:
							throw Error('AGB status not valid in login response.');
					}
				})
				.then(() => {
					$rootScope.$broadcast('authenticationEvent');
					const initialState = Roles.build(roles).isAdministrator() ?
						'administration' : 'contracts';
					const nextState = $stateParams.previous || initialState;
					$state.go(nextState);
				})
				.catch(err => {
					authenticationService.logout();
					vm.loginError = true;
					vm.errorMessage = err.message ||
						'Aufgrund von technischen Problemen können Sie sich derzeit leider nicht einloggen.';
				});
		};

		/**
		 * Reset the password on the server.
		 */
		let resetPassword = () => {
			let resetPasswordData = {
				email: {
					value: undefined,
					required: true
				}
			};

			const modalParams = {
				title: 'Passwort zurücksetzen',
				data: resetPasswordData,
				confirmText: 'Zurücksetzen',
				cancelText: 'Abbrechen'
			};

			modalService.open('password-reset', modalParams)
				.then(() => {
					const data = {
						email: resetPasswordData.email.value,
						url: $window.location.origin + $window.location.pathname + '#!/reset/'
					};

					return apiService.postAccountAction(undefined, 'reset', data);
				})
				.catch(error => {
					$log.warn(error);
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Das Passwort konnte leider nicht zurückgesetzt werden.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
				});
		};

		//
		// Controller API
		//
		vm.isFormComplete = isFormComplete;
		vm.login = login;
		vm.resetPassword = resetPassword;
	}
})(window.angular);
