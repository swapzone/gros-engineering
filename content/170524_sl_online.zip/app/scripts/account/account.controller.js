(function (angular, moment) {

	'use strict';

	angular
		.module('app.account')
		.controller('AccountController', AccountController);

	/* @ngInject */
	function AccountController($log, $scope, $timeout, apiService, modalService, user) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('AccountController');

			if (user.hasOwnProperty('companyData')) {
				vm.companyId = user.companyData.companyNumber;
				vm.company = user.companyData.company;
				vm.legalForm = user.companyData.legalForm;
				vm.street = user.companyData.street;
				vm.zip = user.companyData.zip;
				vm.city = user.companyData.city;
			}

			vm.email = user.email;
			vm.phone = user.phone;

			vm.inputErrorStatus = undefined;
			vm.errorStatus = undefined;
			vm.updateSuccess = undefined;
			vm.formWasSubmitted = false;

			vm.minDate = moment().add(10, 'days');

			$scope.$watch('vm.legalForm', newValue => {
				if (user.hasOwnProperty('companyData')) {
					vm.legalValueHasChanged = newValue !== user.companyData.legalForm;
				}
			});
		};

		/**
		 * Open change password modal.
		 */
		let changePassword = () => {
			$log.info('Change password...');

			let changePasswordData = {
				oldPassword: {
					value: undefined,
					required: true
				},
				password: {
					value: undefined,
					required: true
				},
				passwordConfirm: {
					value: undefined,
					required: true
				}
			};

			const modalParams = {
				title: 'Passwort ändern',
				data: changePasswordData,
				confirmText: 'Speichern',
				cancelText: 'Abbrechen',
				validationFn: formData => {
					if (!formData) {
						return false;
					}
					return formData.oldPassword.value && formData.password.value && formData.passwordConfirm.value
						&& formData.password.value === formData.passwordConfirm.value && formData.password.value.length > 7;
				}
			};

			modalService.open('change-password', modalParams)
				.then(modalData => {
					$log.info(modalData);
					return apiService.postChangePassword(modalData.oldPassword, modalData.passwordConfirm);
				})
				.then(() => {
					modalService.open('alert', {
						title: 'Aktion erfolgreich',
						data: {
							text: {
								value: 'Das Password wurde geändert.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				})
				.catch(error => {
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Das Passwort konnte leider nicht geändert werden. ' +
									'Bitte kontaktieren Sie uns telefonisch oder per Mail.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
					$log.warn(error);
				});
		};

		/**
		 * Checks if all necessary data is given.
		 *
		 * @returns {boolean}
		 */
		let isFormComplete = () => {
			return vm.company && vm.legalForm && vm.street && vm.zip &&
				vm.city && vm.email;
		};

		/**
		 * Stores the user profile data on the server.
		 */
		let updateAccountData = () => {
			const userData = {
				company: vm.company,
				companyNumber: vm.companyId,
				legalForm: vm.legalForm,
				street: vm.street,
				zip: vm.zip,
				email: vm.email,
				city: vm.city
			};

			if (vm.phone || user.phone) {
				userData.phone = vm.phone || '';
			}

			apiService.postUserData(userData)
				.then(() => {
					vm.updateSuccess = true;
					vm.formWasSubmitted = true;

					// update account data in cache
					apiService.userInformation.company = userData.company;
					apiService.userInformation.companyNumber = userData.companyNumber;
					apiService.userInformation.legalForm = userData.legalForm;
					apiService.userInformation.street = userData.street;
					apiService.userInformation.zip = userData.zip;
					apiService.userInformation.email = userData.email;
					apiService.userInformation.city = userData.city;
					apiService.userInformation.phone = userData.phone;

					$timeout(() => {
						vm.updateSuccess = undefined;
					}, 6000);
				})
				.catch(err => {
					$log.error('Could not update user profile data.');
					$log.error(err);

					vm.errorStatus = true;
					vm.errorMessage = 'Ihre Nutzerdaten konnten leider nicht aktualisiert werden.';

					$timeout(() => {
						vm.errorStatus = undefined;
						vm.errorMessage = undefined;
					}, 6000);
				});
		};

		//
		// Controller API
		//
		vm.changePassword = changePassword;
		vm.isFormComplete = isFormComplete;
		vm.updateAccountData = updateAccountData;
	}
})(window.angular, window.moment);
