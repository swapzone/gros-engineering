(function (angular) {

	'use strict';

	angular.module('app.account', [
		'ui.router',
		'app.api',
		'app.common'
	]);
})(window.angular);
