(function (angular) {

	'use strict';

	describe('Module: app.account', () => {
		describe('Component: AccountController', () => {
			let $q;
			let $timeout;
			let apiService;

			let AccountController;

			let user = {
				userId: 6,
				userName: 'user',
				firstName: 'Max',
				lastName: 'Mustermann',
				email: 'max@suedleasing.com',
				phone: '0123/789512',
				companyData: {
					company: 'Test Firma',
					legalForm: 'GmbH',
					street: 'Straße 2',
					zip: '12345',
					city: 'Test Stadt',
				},
				isAdministrator: () => {
					return false;
				},
				isUser: () => {
					return true;
				}
			};

			// first inject the module to test
			beforeEach(module('app.account'));
			// then manually provide the constants / services
			beforeEach(() => {
				module($provide => {
					$provide.constant('user', user);
				});
			});
			// then use the automated injector to inject all required services
			beforeEach(angular.mock.inject((_$controller_, _$q_, _$rootScope_, _$timeout_, _apiService_) => {
				$q = _$q_;
				$timeout = _$timeout_;
				apiService = _apiService_;

				AccountController = _$controller_('AccountController', { $scope: _$rootScope_.$new() });
				AccountController.$onInit();
			}));

			it('should initialize the controller with the user data', () => {
				expect(AccountController.company).toEqual(user.companyData.company);
				expect(AccountController.legalForm).toEqual(user.companyData.legalForm);
				expect(AccountController.street).toEqual(user.companyData.street);
				expect(AccountController.zip).toEqual(user.companyData.zip);
				expect(AccountController.city).toEqual(user.companyData.city);
			});

			it('should render the form to incomplete if data is missing', () => {
				AccountController.street = undefined;
				expect(AccountController.isFormComplete()).toBeFalsy();
			});

			it('should call the apiService for updating the account data', () => {
				spyOn(apiService, 'postUserData').and.returnValue($q.resolve());
				AccountController.updateAccountData();
				expect(apiService.postUserData).toHaveBeenCalled();
			});
		});
	});
})(window.angular);
