(function (angular) {

	'use strict';

	angular
		.module('app.account')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('account', {
			url: '/account',
			parent: 'root',
			templateUrl: 'templates/account/account.html',
			controller: 'AccountController',
			controllerAs: 'vm',
			resolve: {
				/* @ngInject */
				user: ($q, apiService, claimedUserService, sessionService, User) => {
					if (sessionService.isAuthenticated()) {
						return apiService.getUserInformation()
							.then(profileData => {
								const user = new User(profileData);
								if ((user.isUser() && user.hasAcceptedBusinessTerms()) || claimedUserService.hasClaimedUser()) {
									return user;
								}
								return $q.reject();
							});
					}
					return $q.reject();
				}
			}
		});
	}
})(window.angular);
