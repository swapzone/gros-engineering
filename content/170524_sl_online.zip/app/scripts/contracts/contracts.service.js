(function (angular, document) {

	'use strict';

	angular
		.module('app.contracts')
		.service('contractsService', contractsService);

	/* @ngInject */
	function contractsService($log, apiService, modalService) {
		const service = this;

		/**
		 * Open a modal to change the bank account information.
		 *
		 * @param contract
		 */
		let changeBankAccount = (contract) => {
			let changeBankAccountData = {
				currentIban: {
					value: contract.iban,
					required: false,
					readonly: true
				},
				name: {
					value: undefined,
					required: true
				},
				iban: {
					value: undefined,
					required: true
				},
				bic: {
					value: undefined,
					required: false
				},
				bank: {
					value: undefined,
					required: false
				}
			};

			const modalParams = {
				title: 'Kontoverbindung ändern',
				data: changeBankAccountData,
				confirmText: 'Speichern',
				cancelText: 'Abbrechen',
				validationFn: formData => {
					if (!formData) {
						return false;
					}
					return formData.iban.value && formData.name.value;
				}
			};

			modalService.open('bank-account', modalParams)
				.then(modalData => {
					delete modalData.changeData;
					return apiService.postContractAction(contract.id, 'bankAccount', modalData);
				})
				.then(() => {
					modalService.open('alert', {
						title: 'Aktion erfolgreich',
						data: {
							text: {
								value: 'Die Kontoverbindung wurde geändert.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				})
				.catch(error => {
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Die Kontoverbindung konnte leider nicht geändert werden. ' +
									'Bitte kontaktieren Sie uns telefonisch oder per Mail.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
					$log.warn(error);
				});
		};

		/**
		 * Initiate download of contract documents.
		 *
		 * @param contract
		 */
		let downloadContractDocument = (contract) => {
			apiService.getContractDocuments(contract)
				.then(documentArray => {
					if (documentArray.length === 0) {
						modalService.open('alert', {
							title: 'Aktion erfolgreich',
							data: {
								text: {
									value: 'Die Vertragsdokumente wurden erfolgreich angefordert.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					} else {
						documentArray.forEach(documentObject => {
							let uri = 'data:application/pdf;base64,' + documentObject.data;
							let link = angular.element('<a href="' + uri + '" target="_blank"></a>');

							angular.element(document.body).append(link);
							link[0].click();
							link.remove();
						});
					}
				})
				.catch(err => {
					$log.error('Could not retrieve the contract document:');
					$log.error(err);
					modalService.open('alert', {
						title: 'Aktion fehlgeschlagen',
						data: {
							text: {
								value: 'Das Vertragsdokument kann im Moment leider nicht abgerufen werden.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				});
		};

		/**
		 * Create extend contract modal and send data to back end.
		 *
		 * @param contract
		 */
		let extendContract = (contract) => {
			let extendContractData = {
				date: {
					value: undefined,
					required: true
				},
				annotation: {
					value: undefined,
					required: false
				}
			};

			const modalParams = {
				title: 'Vertragsverlängerung',
				data: extendContractData,
				confirmText: 'Vertrag verlängern',
				cancelText: 'Abbrechen'
			};

			modalService.open('extend-contract', modalParams)
				.then(modalData => {
					return apiService.postContractAction(contract.id, 'extend', modalData);
				})
				.then(() => {
					modalService.open('alert', {
						title: 'Aktion erfolgreich',
						data: {
							text: {
								value: 'Die Vertragsverlängerung wurde beantragt.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				})
				.catch(error => {
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Die Vertragsverlängerung konnte leider nicht durchgeführt werden. ' +
										'Bitte kontaktieren Sie uns telefonisch oder per Mail.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
					$log.warn(error);
				});
		};

		/**
		 * Create cancel contract modal and send data to back end.
		 *
		 * @param contract
		 */
		let cancelContract = (contract) => {
			let cancelContractData = {
				contract: {
					value: contract,
					required: false,
					readonly: true
				},
				date: {
					value: undefined,
					required: true
				},
				annotation: {
					value: undefined,
					required: false
				}
			};

			const modalParams = {
				title: 'Vertrag ablösen',
				data: cancelContractData,
				confirmText: 'Vertrag ablösen',
				cancelText: 'Abbrechen'
			};

			modalService.open('cancel-contract', modalParams)
				.then(() => {
					const data = {};
					for (let property in cancelContractData) {
						if (cancelContractData.hasOwnProperty(property) && !cancelContractData[property].readonly) {
							data[property] = cancelContractData[property].value;
						}
					}

					return apiService.postContractAction(contract.id, 'cancel', data);
				})
				.then(() => {
					modalService.open('alert', {
						title: 'Aktion erfolgreich',
						data: {
							text: {
								value: 'Die Vertragsablösung wurde beantragt.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				})
				.catch(error => {
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Die Vertragsablösung konnte leider nicht durchgeführt werden. ' +
									'Bitte kontaktieren Sie uns telefonisch oder per Mail.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
					$log.warn(error);
				});
		};

		/**
		 * Create balance confirmation modal and send data to back end.
		 *
		 * @param contract
		 */
		let requestBalanceConfirmation = (contract) => {
			let balanceConfirmationData = {
				date: {
					value: undefined,
					required: true
				},
				transport: {
					value: 'email',
					required: true
				},
				annotation: {
					value: undefined,
					required: false
				}
			};

			const modalParams = {
				title: 'Saldenbestätigung anfordern',
				data: balanceConfirmationData,
				confirmText: 'Anfordern',
				cancelText: 'Abbrechen'
			};

			modalService.open('balance-confirmation', modalParams)
				.then(() => {
					const data = {};
					for (let property in balanceConfirmationData) {
						if (balanceConfirmationData.hasOwnProperty(property)) {
							data[property] = balanceConfirmationData[property].value;
						}
					}

					return apiService.postContractAction(contract.id, 'balanceAcknowledgement', data);
				})
				.then(() => {
					modalService.open('alert', {
						title: 'Aktion erfolgreich',
						data: {
							text: {
								value: 'Die Saldenbestätigung wurde angefordert.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				})
				.catch(error => {
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Die Saldenbestätigung konnte leider nicht angefordert werden. ' +
									'Bitte kontaktieren Sie uns telefonisch oder per Mail.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
					$log.warn(error);
				});
		};

		/**
		 * Show a form to the user to input the details of the notification of
		 * claim.
		 *
		 * @param contract
		 */
		let sendClaimReport = (contract) => {
			let claimReportData = {
				insurance: {
					value: undefined,
					required: true
				},
				street: {
					value: undefined,
					required: false
				},
				zip: {
					value: undefined,
					required: true
				},
				city: {
					value: undefined,
					required: true
				},
				insuranceNumber: {
					value: undefined,
					required: false
				},
				incidentDate: {
					value: undefined,
					required: true
				},
				claimReportNumber: {
					value: undefined,
					required: false
				},
				amountOfLoss: {
					value: undefined,
					required: false
				},
				totalLoss: {
					value: false,
					required: false
				},
				damageRepair: {
					value: false,
					required: false
				}
			};

			const modalParams = {
				title: 'Versicherungsschaden melden',
				data: claimReportData,
				confirmText: 'Schadenmeldung senden',
				cancelText: 'Abbrechen',
				validationFn: formData => {
					if (!formData) {
						return false;
					}
					return formData.claimReportNumber.value || formData.insuranceNumber.value;
				}
			};

			modalService.open('claim-report', modalParams)
				.then(() => {
					$log.debug('Send claim report for contract: ');
					$log.debug(contract);

					const data = {};
					for (let property in claimReportData) {
						if (claimReportData.hasOwnProperty(property)) {
							data[property] = claimReportData[property].value;
						}
					}

					return apiService.postContractAction(contract.id, 'claimReport', data);
				})
				.then(() => {
					modalService.open('alert', {
						title: 'Aktion erfolgreich',
						data: {
							text: {
								value: 'Der Versicherungsschaden wurde erfolgreich übertragen.'
							}
						},
						confirmText: 'Ok',
						cancelText: undefined
					});
				})
				.catch(error => {
					if (error !== 'Modal was closed.') {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Der Versicherungsschaden konnte leider nicht gemeldet werden. ' +
									'Bitte kontaktieren Sie uns telefonisch oder per Mail.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
					}
					$log.warn(error);
				});
		};

		//
		// Service API
		//
		service.changeBankAccount = changeBankAccount;
		service.downloadContractDocument = downloadContractDocument;
		service.extendContract = extendContract;
		service.cancelContract = cancelContract;
		service.requestBalanceConfirmation = requestBalanceConfirmation;
		service.sendClaimReport = sendClaimReport;
	}
})(window.angular, window.document);
