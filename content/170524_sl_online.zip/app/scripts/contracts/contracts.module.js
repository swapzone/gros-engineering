(function (angular) {

	'use strict';

	angular.module('app.contracts', [
		'ui.router',
		'app.api',
		'app.common'
	]);
})(window.angular);
