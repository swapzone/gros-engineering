(function (angular) {

	'use strict';

	angular
		.module('app.contracts')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('contracts', {
			url: '/contracts',
			parent: 'root',
			templateUrl: 'templates/contracts/contracts.html',
			controller: 'ContractsController',
			controllerAs: 'vm',
			resolve: {
				/* @ngInject */
				user: ($q, apiService, claimedUserService, sessionService, User) => {
					if (sessionService.isAuthenticated()) {
						return apiService.getUserInformation()
							.then(profileData => {
								const user = new User(profileData);
								if ((user.isUser() && user.hasAcceptedBusinessTerms()) || claimedUserService.hasClaimedUser()) {
									return user;
								}
								return $q.reject();
							});
					}
					return $q.reject('Not authenticated.');
				}
			}
		});
	}
})(window.angular);
