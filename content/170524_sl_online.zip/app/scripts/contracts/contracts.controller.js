(function (angular, $) {

	'use strict';

	angular
		.module('app.contracts')
		.controller('ContractsController', ContractsController);

	/* @ngInject */
	function ContractsController($log, $scope, $timeout, apiService, contractsService, user) {
		const vm = this;

		const CONTRACT_PAGE_SIZE = 10;

		let openMenu = -1;

		vm.pages = [];
		vm.currentPage = undefined;
		vm.sortField = undefined;
		vm.filters = {};

		vm.$onInit = () => {
			$log.debug('ContractsController');

			apiService.getContracts(0, CONTRACT_PAGE_SIZE, undefined, vm.sortField)
				.then(result => {
					let contracts = result.contracts;
					vm.numberOfContracts = result.numberOfItems;

					if (vm.numberOfContracts > CONTRACT_PAGE_SIZE) {
						const numberOfPages = Math.ceil(vm.numberOfContracts / CONTRACT_PAGE_SIZE);
						for (let i = 1; i < numberOfPages + 1; i++) {
							vm.pages.push(i);
						}
						vm.currentPage = 1;
						vm.contracts = contracts;
					} else {
						vm.pages = [1];
						vm.currentPage = 1;
						vm.contracts = contracts;
					}
				})
				.catch($log.error);

			$scope.$watchCollection('vm.filters', newValue => {
				if (newValue &&
					(newValue.hasOwnProperty('startDate') || newValue.hasOwnProperty('endDate') ||
					newValue.hasOwnProperty('status') || newValue.hasOwnProperty('type'))) {
					filterChanged();
				}
			});
		};

		/**
		 * Returns true if the user is allowed to download contract documents.
		 *
		 * @returns {boolean|*}
		 */
		let canDownloadContractDocuments = () => {
			return user.contractDownloadAllowed;
		};

		/**
		 * Change page and show contracts accordingly.
		 *
		 * @param page
		 */
		let changePage = page => {
			const startIndex = (page - 1) * CONTRACT_PAGE_SIZE;
			apiService.getContracts(startIndex, CONTRACT_PAGE_SIZE, vm.searchQuery, vm.sortField)
				.then(result => {
					vm.currentPage = page;
					vm.contracts = result.contracts;
				})
				.catch($log.error);
		};

		let isActionMenuOpen = id => {
			return openMenu === id;
		};

		let clickHandler = event => {
			let actionMenuElement = $('#sl-contracts-action-menu');
			if (actionMenuElement.length === 0) {
				return;
			}

			let offset = actionMenuElement.offset();
			let menuPosition = {
				xMin: offset.left,
				yMin: offset.top,
				xMax: offset.left + actionMenuElement.height(),
				yMax: offset.top + actionMenuElement.width()
			};
			let yClickPosition = event.clientY;
			let xClickPosition = event.clientX;

			let notWithinX = xClickPosition < menuPosition.xMin ||
				xClickPosition > menuPosition.xMax;

			let notWithinY = yClickPosition < menuPosition.yMin ||
				yClickPosition > menuPosition.yMax;

			if (notWithinX || notWithinY) {
				$log.debug('Click event registered outside of menu!');
				$timeout(() => {
					openMenu = -1;
				});

				// de-register click listener
				window.removeEventListener('click', clickHandler, false);
			}
		};

		/**
		 * Filter changed handler.
		 */
		let filterChanged = () => {
			$log.info('Filter changed!');

			apiService.getContracts(0, CONTRACT_PAGE_SIZE, vm.searchQuery, vm.sortField, vm.filters)
				.then(result => {
					let contracts = result.contracts;
					let numberOfMatchingContracts = result.numberOfItems;

					if (numberOfMatchingContracts > CONTRACT_PAGE_SIZE) {
						const numberOfPages = Math.ceil(numberOfMatchingContracts / CONTRACT_PAGE_SIZE);
						vm.pages = [];
						for (let i = 1; i < numberOfPages + 1; i++) {
							vm.pages.push(i);
						}
						vm.currentPage = 1;
						vm.contracts = contracts;
					} else {
						vm.pages = [1];
						vm.currentPage = 1;
						vm.contracts = contracts;
					}
				})
				.catch($log.error);
		};

		/**
		 * Sort order changed handler.
		 */
		let sortOrderChanged = () => {
			apiService.getContracts(0, CONTRACT_PAGE_SIZE, vm.searchQuery, vm.sortField, vm.filters)
				.then(result => {
					let contracts = result.contracts;
					let numberOfMatchingContracts = result.numberOfItems;

					if (numberOfMatchingContracts > CONTRACT_PAGE_SIZE) {
						const numberOfPages = Math.ceil(numberOfMatchingContracts / CONTRACT_PAGE_SIZE);
						vm.pages = [];
						for (let i = 1; i < numberOfPages + 1; i++) {
							vm.pages.push(i);
						}
						vm.currentPage = 1;
						vm.contracts = contracts;
					} else {
						vm.pages = [1];
						vm.currentPage = 1;
						vm.contracts = contracts;
					}
				})
				.catch($log.error);
		};

		/**
		 * Open menu and prevent click event from bubbling up.
		 *
		 * @param event
		 * @param id
		 */
		let toggleActionMenu = (event, id) => {
			event.stopPropagation();
			if (openMenu === -1) {
				window.addEventListener('click', clickHandler);
			}
			openMenu = openMenu === id ? -1 : id;
		};

		/**
		 * Trigger a search request in the back end.
		 *
		 * @param query
		 */
		let searchContracts = query => {
			$log.debug('Search contracts: ' + query);

			apiService.getContracts(0, CONTRACT_PAGE_SIZE, query, vm.sortField, vm.filters)
				.then(result => {
					let contracts = result.contracts;
					let numberOfMatchingContracts = result.numberOfItems;

					if (numberOfMatchingContracts > CONTRACT_PAGE_SIZE) {
						const numberOfPages = Math.ceil(numberOfMatchingContracts / CONTRACT_PAGE_SIZE);
						vm.pages = [];
						for (let i = 1; i < numberOfPages + 1; i++) {
							vm.pages.push(i);
						}
						vm.currentPage = 1;
						vm.contracts = contracts;
					} else {
						vm.pages = [1];
						vm.currentPage = 1;
						vm.contracts = contracts;
					}
				})
				.catch($log.error);
		};

		//
		// Controller API
		//
		vm.changeBankAccount = contractsService.changeBankAccount;
		vm.downloadContractDocument = contractsService.downloadContractDocument;
		vm.extendContract = contractsService.extendContract;
		vm.cancelContract = contractsService.cancelContract;
		vm.canDownloadContractDocuments = canDownloadContractDocuments;
		vm.changePage = changePage;
		vm.isActionMenuOpen = isActionMenuOpen;
		vm.toggleActionMenu = toggleActionMenu;
		vm.requestBalanceConfirmation = contractsService.requestBalanceConfirmation;
		vm.searchContracts = searchContracts;
		vm.sendClaimReport = contractsService.sendClaimReport;
		vm.filterChanged = filterChanged;
		vm.sortOrderChanged = sortOrderChanged;
	}
})(window.angular, window.$);
