(function (angular, jasmine) {
	'use strict';

	describe('Module: app.contracts', () => {
		describe('Component: contractsService', () => {
			let apiService;
			let contractsService;
			let modalService;
			let $log;
			let $q;
			let $window;

			beforeEach(module('app.contracts'));
			beforeEach(angular.mock.inject((_$log_, _$q_, _$window_, _apiService_, _contractsService_, _modalService_) => {
				$log = _$log_;
				$q = _$q_;
				$window = _$window_;
				apiService = _apiService_;
				contractsService = _contractsService_;
				modalService = _modalService_;
			}));

			it('should open a modal and call the API when extending the contract', () => {
				let returnValue = $q.resolve();
				spyOn(modalService, 'open').and.returnValue(returnValue);
				spyOn(apiService, 'postContractAction').and.returnValue($q.resolve());

				contractsService.extendContract({
					contractNumber: '1234'
				});

				expect(modalService.open).toHaveBeenCalledWith('extend-contract', jasmine.any(Object));
				returnValue.then(() => {
					expect(apiService.postContractAction)
						.toHaveBeenCalledWith('1234', 'extend', jasmine.any(Object));
				});
			});

			it('should open a modal and call the API when cancelling the contract', () => {
				let returnValue = $q.resolve();
				spyOn(modalService, 'open').and.returnValue(returnValue);
				spyOn(apiService, 'postContractAction').and.returnValue($q.resolve());

				contractsService.cancelContract({
					contractNumber: '1234'
				});

				expect(modalService.open).toHaveBeenCalledWith('cancel-contract', jasmine.any(Object));
				returnValue.then(() => {
					expect(apiService.postContractAction)
						.toHaveBeenCalledWith('1234', 'cancel', jasmine.any(Object));
				});
			});

			it('should open a modal and call the API when requesting a balance confirmation', () => {
				let returnValue = $q.resolve();
				spyOn(modalService, 'open').and.returnValue(returnValue);
				spyOn(apiService, 'postContractAction').and.returnValue($q.resolve());

				contractsService.requestBalanceConfirmation({
					contractNumber: '1234'
				});

				expect(modalService.open).toHaveBeenCalledWith('balance-confirmation', jasmine.any(Object));
				returnValue.then(() => {
					expect(apiService.postContractAction)
						.toHaveBeenCalledWith('1234', 'balanceAcknowledgement', jasmine.any(Object));
				});
			});

			it('should open a modal and call the API when sending a claim report', () => {
				let returnValue = $q.resolve();
				spyOn(modalService, 'open').and.returnValue(returnValue);
				spyOn(apiService, 'postContractAction').and.returnValue($q.resolve());

				contractsService.sendClaimReport({
					contractNumber: '1234'
				});

				expect(modalService.open).toHaveBeenCalledWith('claim-report', jasmine.any(Object));
				returnValue.then(() => {
					expect(apiService.postContractAction)
						.toHaveBeenCalledWith('1234', 'claimReport', jasmine.any(Object));
				});
			});
		});
	});
})(window.angular, window.jasmine);
