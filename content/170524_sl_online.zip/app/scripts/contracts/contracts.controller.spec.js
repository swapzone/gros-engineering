(function (angular) {

	'use strict';

	describe('Module: app.contracts', () => {
		describe('Component: ContractsController', () => {
			let $q;
			let $timeout;
			let apiService;

			let ContractsController;

			let user = {
				userId: 6,
				userName: 'user',
				firstName: 'Max',
				lastName: 'Mustermann',
				email: 'max@suedleasing.com',
				phone: '0123/789512',
				companyData: {
					company: 'Test Firma',
					legalForm: 'GmbH',
					street: 'Straße 2',
					zip: '12345',
					city: 'Test Stadt',
				},
				isAdministrator: () => {
					return false;
				},
				isUser: () => {
					return true;
				}
			};

			const contractsMock = [
				{	contractNumber: '1' },
				{	contractNumber: '2' },
				{	contractNumber: '3' }
			];

			// first inject the module to test
			beforeEach(module('app.contracts'));
			// then manually provide the constants / services
			beforeEach(() => {
				module($provide => {
					$provide.constant('user', user);
				});
			});
			// then use the automated injector to inject all required services
			beforeEach(angular.mock.inject((_$controller_, _$q_, _$rootScope_, _$timeout_, _apiService_) => {
				$q = _$q_;
				$timeout = _$timeout_;
				apiService = _apiService_;

				ContractsController = _$controller_('ContractsController', {
					$scope: _$rootScope_.$new()
				});

				spyOn(apiService, 'getContracts').and.returnValue($q.resolve(contractsMock));
				ContractsController.$onInit();
			}));

			it('should initialize the controller with the right data', () => {
				$timeout(() => {
					expect(ContractsController.contracts).toEqual(contractsMock);
				});
			});

			it('should retrieve the contracts from the API on being initialized', () => {
				expect(apiService.getContracts).toHaveBeenCalled();
			});
		});
	});
})(window.angular);
