(function (angular) {

	'use strict';

	angular
		.module('app.contact')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('contact', {
			url: '/contact',
			parent: 'root',
			templateUrl: 'templates/contact/contact.html',
			controller: 'ContactController',
			controllerAs: 'vm',
			resolve: {
				/* @ngInject */
				user: (apiService, sessionService, User) => {
					if (sessionService.isAuthenticated()) {
						return apiService.getUserInformation()
							.then(profileData => {
								return new User(profileData);
							});
					}
					return new User();
				}
			}
		});
	}
})(window.angular);
