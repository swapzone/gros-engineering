(function (angular) {

	'use strict';

	describe('Module: app.contact', () => {
		describe('Component: ContactController', () => {
			let $q;
			let $window;
			let apiService;

			let ContactController;

			let userMock = {
				userId: '6',
				firstName: 'Max',
				lastName: 'Mustermann',
				email: 'max@suedleasing.com',
				phone: '01234/12345'
			};

			// first inject the module to test
			beforeEach(module('app.contact'));
			// then manually provide the constants / services
			beforeEach(() => {
				module($provide => {
					$provide.constant('user', userMock);
				});
			});
			// then use the automated injector to inject all required services
			beforeEach(angular.mock.inject((_$controller_, _$q_, _$window_, _apiService_) => {
				$q = _$q_;
				$window = _$window_;
				apiService = _apiService_;

				$window.SL_ONLINE_CONTACT_SUBJECTS = [
					'Category 1',
					'Category 2',
					'Category 3'
				];

				ContactController = _$controller_('ContactController', {});
				ContactController.$onInit();
			}));

			it('should initialize the controller with an existing user object', () => {
				expect(ContactController.contact).toEqual('email');
				expect(ContactController.availableSubjects).toEqual([
					'Category 1',
					'Category 2',
					'Category 3'
				]);
				expect(ContactController.name).toEqual('Max Mustermann');
				expect(ContactController.email).toEqual('max@suedleasing.com');
				expect(ContactController.phone).toEqual('01234/12345');
			});

			it('should set the form to incomplete if the contact via email is selected but no email is given', () => {
				ContactController.contact = 'email';
				ContactController.email = undefined;
				ContactController.name = 'Test';
				ContactController.subject = 'Test';
				ContactController.message = 'Test';

				expect(ContactController.isFormComplete()).toBeFalsy();
			});

			it('should validate the form to complete if all data is properly given', () => {
				ContactController.contact = 'email';
				ContactController.subject = 'Test';
				ContactController.message = 'Test';

				expect(ContactController.isFormComplete()).toBeTruthy();
			});

			it('should call the right API for a contact request', () => {
				let returnValue = $q.resolve();
				spyOn(apiService, 'postContactRequest').and.returnValue(returnValue);
				ContactController.contact = 'email';
				ContactController.subject = 'Test';
				ContactController.message = 'Test';

				ContactController.sendContactRequest();

				expect(apiService.postContactRequest).toHaveBeenCalledWith({
					name: 'Max Mustermann',
					phone: '01234/12345',
					email: 'max@suedleasing.com',
					contact: 'email',
					subject: 'Test',
					message: 'Test'
				});

				returnValue.then(() => {
					expect(ContactController.successMessage).toBe('Die Nachricht wurde gesendet, vielen Dank.');
				});
			});
		});
	});
})(window.angular);
