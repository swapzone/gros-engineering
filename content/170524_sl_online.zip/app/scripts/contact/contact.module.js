(function (angular) {

	'use strict';

	angular.module('app.contact', [
		'ui.router',
		'app.api',
		'app.common'
	]);
})(window.angular);
