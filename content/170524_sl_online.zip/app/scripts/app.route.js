(function (angular, moment) {

	'use strict';

	angular
		.module('app')
		.config(config)
		.config(localConfig);

	/* @inject */
	function config($qProvider, $httpProvider, $stateProvider, $urlRouterProvider) {
		// do not treat rejected Promises as exceptions
		$qProvider.errorOnUnhandledRejections(false);

		// the authInterceptor handles the 401 status code from the back end
		$httpProvider.interceptors.push('authInterceptor');
		$httpProvider.interceptors.push('requestInterceptor');

		$urlRouterProvider.otherwise('/login');

		$stateProvider.state('root', {
		  abstract: true,
			templateUrl: 'templates/app.html',
			controller: 'AppController',
			controllerAs: 'vm',
			resolve: {
				/* @ngInject */
				user: (apiService, sessionService, User) => {
					if (sessionService.isAuthenticated()) {
						return apiService.getUserInformation()
							.then(profileData => {
								return new User(profileData);
							});
					}
					return new User();
				}
			}
		});
	}

	/* @inject */
	function localConfig($compileProvider, momentPickerProvider) {
		$compileProvider.debugInfoEnabled(false);
		moment.locale('de');
		momentPickerProvider.options({
			locale: 'de'
		});
	}
})(window.angular, window.moment);

