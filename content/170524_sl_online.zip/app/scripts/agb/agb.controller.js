(function (angular) {

	'use strict';

	angular
		.module('app.agb')
		.controller('AgbController', AgbController);

	/* @ngInject */
	function AgbController($log, apiService, agbVersion) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('AgbController');

			apiService.getAgbContent(agbVersion)
				.then(content => {
					vm.agbContent = content;
				});
		};
	}
})(window.angular);
