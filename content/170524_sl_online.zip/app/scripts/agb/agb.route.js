(function (angular) {

	'use strict';

	angular
		.module('app.agb')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('agb', {
			url: '/agb',
			parent: 'root',
			templateUrl: 'templates/agb/agb.html',
			controller: 'AgbController',
			controllerAs: 'vm',
			resolve: {
				/* @ngInject */
				agbVersion: (apiService) => {
					return apiService.getAgbVersion();
				}
			}
		});
	}
})(window.angular);
