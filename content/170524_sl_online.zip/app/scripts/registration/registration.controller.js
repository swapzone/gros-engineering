(function (angular) {

	'use strict';

	angular
		.module('app.registration')
		.controller('RegistrationController', RegistrationController);

	/* @ngInject */
	function RegistrationController($log, $state, apiService, modalService, registrationService) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('RegistrationController');

			vm.formData = {
				value: {}
			};
		};

		/**
		 * Returns true if all required data is given.
		 *
		 * @returns {boolean}
		 */
		let isFormComplete = () => {
			let result =
				registrationService.validateRegistrationData(vm.formData);

			const complete =
				result.dataAvailable && result.passwordIsValid && !result.failsPasswordCriteria;

			return complete && vm.userConfirmation && vm.privacyAgreement;
		};

		/**
		 * Register a new user.
		 */
		let register = () => {
			if (isFormComplete()) {
				apiService.register(
					vm.formData.value.username,
					vm.formData.value.password,
					vm.formData.value.firstname,
					vm.formData.value.lastname,
					vm.formData.value.email,
					vm.formData.value.contractNumber,
					vm.formData.value.company
				)
					.then(() => {
						$state.go('login');
					})
					.catch(err => {
						modalService.open('alert', {
							title: 'Aktion fehlgeschlagen',
							data: {
								text: {
									value: 'Account konnte leider nicht erstellt werden.'
								}
							},
							confirmText: 'Ok',
							cancelText: undefined
						});
						$log.error(err);
					});
			}
		};

		//
		// Controller API
		//
		vm.isFormComplete = isFormComplete;
		vm.register = register;
	}
})(window.angular);
