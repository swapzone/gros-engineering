(function (angular) {

	'use strict';

	angular.module('app.registration', [
		'ui.router',
		'app.common',
		'app.api'
	]);
})(window.angular);
