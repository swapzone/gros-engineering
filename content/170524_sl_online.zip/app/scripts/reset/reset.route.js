(function (angular) {

	'use strict';

	angular
		.module('app.reset')
		.config(routerConfig);

	/* @ngInject */
	function routerConfig($stateProvider) {

		$stateProvider.state('passwordReset', {
			url: '/reset/:hash',
			parent: 'root',
			template: '<div class="sl-reset"></div>',
			controller: 'ResetController',
			controllerAs: 'vm'
		});
	}
})(window.angular);
