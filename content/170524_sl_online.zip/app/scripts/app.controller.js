(function (angular) {

	'use strict';

	angular
		.module('app')
		.controller('AppController', AppController);

	/* @ngInject */
	function AppController($log, $rootScope, apiService, sessionService, user, User) {
		const vm = this;

		vm.$onInit = () => {
			$log.debug('AppController');
			$rootScope.user = vm.user = user;

			$rootScope.$on('userClaimed', resetUser);
			$rootScope.$on('authenticationEvent', resetUser);

			function resetUser() {
				$log.debug('User is re-initialized.');
				if (sessionService.isAuthenticated()) {
					apiService.getUserInformation()
						.then(userInformation => {
							$rootScope.user = vm.user = new User(userInformation);
						});
				} else {
					vm.user = new User();
				}
			}
		};

		/**
		 * Set the variable to false that controls the menu state.
		 */
		let closeMenu = () => {
			vm.showSubmenu = false;
		};

		/**
		 * Toggle the variable controlling the menu state.
		 */
		let toggleMenu = () => {
			vm.showSubmenu = !vm.showSubmenu;
		};

		//
		// Controller API
		//
		vm.closeMenu = closeMenu;
		vm.toggleMenu = toggleMenu;
	}
})(window.angular);

