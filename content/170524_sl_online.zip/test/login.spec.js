(function () {

	'use strict';

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function() {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(8000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Login', function () {
		this.timeout(30000);

		beforeEach(function () {
			driver.get(APP_URL + '/#!/login');
		});

		it('should open the login section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/login').notify(done);
		});

		it('should have the SuedLeasing slogan in the window\'s title', done => {
			expect(driver.getTitle()).to.eventually.contain('SüdLeasing - Man least viel Gutes über uns').notify(done);
		});

		it('should have a login button', done => {
			let buttonText = driver.findElement(By.css('.sl-login .sl-login-form .sl-button')).getText();
			expect(buttonText).to.eventually.equal('LOGIN').notify(done);
		});

		it('should deactivate the login button as long as username or password is missing', done => {
			let disabled = driver.findElement(By.css('.sl-login .sl-login-form .sl-button')).getAttribute('disabled');
			expect(disabled).to.eventually.equal('true').notify(done);
		});

		it('should activate the login button when username and password is given', done => {
			driver.findElement(By.name('username')).sendKeys('user');
			driver.findElement(By.name('password')).sendKeys('password');

			let disabled = driver.findElement(By.css('.sl-login .sl-login-form .sl-button')).getAttribute('disabled');
			expect(disabled).to.eventually.equal(null).notify(done);
		});

		it('should link to the registration section', done => {
			driver.findElement({
				linkText: 'Registrieren'
			}).click();

			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/registration').notify(done);
		});

		it('should authenticate the client and head to the administration section', done => {
			driver.findElement(By.name('username')).sendKeys('user');
			driver.findElement(By.name('password')).sendKeys('password');

			driver.findElement(By.css('.sl-login .sl-login-form .sl-button')).click().then(() => {
				driver.navigate().refresh().then(() => {
					driver.get(APP_URL + '/#!/administration');
					expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/administration').notify(done);
				});
			});
		});
	});
})();
