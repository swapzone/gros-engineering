(function () {

	'use strict';

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function() {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Reset', function() {
		this.timeout(30000);

		it('should not show a reset form if no hash is given', done => {
			driver.get(APP_URL + '/#!/reset/');

			driver.findElements(By.css('.sl-form-reset-password'))
				.then(elements => {
					expect(elements.length).to.equal(0);
					done();
				});
		});

		it('should show a password reset form', done => {
			driver.get(APP_URL + '/#!/reset/123456789');

			driver.findElements(By.css('.sl-form-reset-password'))
				.then(elements => {
					expect(elements.length).to.equal(1);
					done();
				});
		});

		it('should deactivate the submit button if no password is given', done => {
			driver.get(APP_URL + '/#!/reset/123456789');

			driver.findElements(By.css('.sl-modal-action-bar > button'))
				.then(elements => {
					expect(elements.length).to.equal(2);

					elements[0].getAttribute('disabled').then(disabled => {
						expect(disabled).to.equal('true');
						done();
					});
				});
		});

		it('should activate the submit button if a valid password is given', done => {
			driver.get(APP_URL + '/#!/reset/123456789');

			driver.findElement(By.name('password')).sendKeys('test123');
			driver.findElement(By.name('password-confirm')).sendKeys('test123');

			driver.findElements(By.css('.sl-modal-action-bar > button'))
				.then(elements => {
					expect(elements.length).to.equal(2);

					setTimeout(() => {
						elements[0].getAttribute('disabled').then(disabled => {
							expect(disabled).to.equal(null);
							done();
						});
					}, 1500);
				});
		});
	});
})();
