(function () {

	'use strict';

	let contracts = require('../mock/contracts.json');

	const {Builder, By} = require('selenium-webdriver');
	const chai = require('chai');
	const expect = chai.expect;

	chai.use(require('chai-as-promised'));

	const APP_URL = 'http://localhost:8000';
	let driver;

	before(function(done) {
		this.timeout(10000);

		driver = new Builder()
			.forBrowser('phantomjs')
			.build();

		driver.manage().timeouts().implicitlyWait(5000);
		// run tests for desktop screens
		driver.manage().window().setPosition(0, 0);
		driver.manage().window().setSize(1024, 768);

		driver.get(APP_URL);
		driver.executeScript(function () {
			return sessionStorage.setItem('ngStorage-sl-user-token', '\"FakeToken\"');
		});
		driver.navigate().refresh().then(() => {
			done();
		});
	});

	after(function() {
		if (driver) {
			driver.close();
			driver.quit();
		}
	});

	describe('Module: Contracts', function() {
		this.timeout(30000);

		beforeEach(function() {
			driver.get(APP_URL + '/#!/contracts');
		});

		it('should open the contracts section', done => {
			expect(driver.getCurrentUrl()).to.eventually.equal(APP_URL + '/#!/contracts').notify(done);
		});

		it('should show all contracts of a customer in a table', done => {
			driver.findElements(By.className('sl-contracts-item'))
				.then(elements => {
					const PAGE_SIZE = 10;
					const numberOfContracts = contracts.length;

					let elementsInTable = numberOfContracts > PAGE_SIZE ? PAGE_SIZE : numberOfContracts;
					expect(elements.length).to.equal(elementsInTable);
					done();
				});
		});

		it('should show the filters when clicking on it', done => {
			driver.findElement(By.css('.sl-element-toggle.filter')).click();
			let placeholder = driver.findElement(By.css('.date-picker')).getAttribute('placeholder');
			expect(placeholder).to.eventually.equal('DD.MM.YYYY').notify(done);
		});

		it('should show the sort field selection when clicking on it', done => {
			driver.findElement(By.css('.sl-element-toggle.sort')).click();
			let ngModel = driver.findElement(By.id('sort-field')).getAttribute('data-ng-model');
			expect(ngModel).to.eventually.equal('vm.sortField').notify(done);
		});

		it('should open a the menu when clicking on the contract action button', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			let elementText = driver.findElement(By.css('.sl-contracts-action-menu > a:last-of-type')).getText();
			expect(elementText).to.eventually.equal('Bankverbindung ändern').notify(done);
		});

		it('should open a modal when clicking on a menu item', done => {
			driver.findElement(By.css('.sl-contracts-actions > a:first-of-type')).click();
			driver.findElement(By.css('.sl-contracts-action-menu > a:nth-of-type(4)')).click();
			let modalTitle = driver.findElement(By.css('.sl-modal-title')).getText();
			expect(modalTitle).to.eventually.equal('VERTRAGSVERLÄNGERUNG').notify(done);
		});

		it('should load new contracts when going to another page', done => {
			setTimeout(() => {
				driver.findElement(By.css('.pagination > a:nth-of-type(3)')).click();
				let spinnerAttribute = driver.findElement(By.css('.waiting-spinner-modal')).getAttribute('class');
				expect(spinnerAttribute).to.eventually.equal('waiting-spinner-modal active').notify(done);
			}, 3000);
		});
	});
})();
